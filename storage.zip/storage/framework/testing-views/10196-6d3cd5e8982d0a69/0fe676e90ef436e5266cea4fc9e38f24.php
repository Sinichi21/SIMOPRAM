<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <?php echo $__env->make('partials.head', ['title' => $school->name], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <meta name="description" content="<?php echo e($school->tagline ?: 'Profil dan kegiatan Pramuka '.$school->name); ?>">
    <style>:root { --school-color: <?php echo e(preg_match('/^#[0-9a-fA-F]{6}$/', $school->primary_color ?? '') ? $school->primary_color : '#166534'); ?>; }</style>
</head>
<body class="simpram-app min-h-screen bg-[#f7f5ee] text-zinc-900 antialiased dark:bg-zinc-950 dark:text-zinc-100">
    <?php if (isset($component)) { $__componentOriginal2669d93ac3865159955b6d09c48349b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2669d93ac3865159955b6d09c48349b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-header','data' => ['school' => $school]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['school' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($school)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2669d93ac3865159955b6d09c48349b9)): ?>
<?php $attributes = $__attributesOriginal2669d93ac3865159955b6d09c48349b9; ?>
<?php unset($__attributesOriginal2669d93ac3865159955b6d09c48349b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2669d93ac3865159955b6d09c48349b9)): ?>
<?php $component = $__componentOriginal2669d93ac3865159955b6d09c48349b9; ?>
<?php unset($__componentOriginal2669d93ac3865159955b6d09c48349b9); ?>
<?php endif; ?>

    <main>
        <section class="relative grid min-h-[760px] place-items-end overflow-hidden bg-[var(--school-color)] text-white">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school->hero_image): ?><img src="<?php echo e(Storage::url($school->hero_image)); ?>" class="absolute inset-0 size-full object-cover opacity-45" alt="Kegiatan <?php echo e($school->name); ?>"><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-black/20"></div><div class="absolute right-[-8rem] top-24 size-[34rem] rounded-full border-[90px] border-white/5"></div>
            <div class="relative mx-auto w-full max-w-7xl px-5 pb-20 pt-40 lg:px-8 lg:pb-24">
                <p class="text-sm font-bold uppercase tracking-[.22em] text-amber-300">Gerakan Pramuka · <?php echo e($school->city ?: 'Indonesia'); ?></p>
                <h1 class="mt-5 max-w-5xl text-5xl font-black leading-[.95] tracking-[-.045em] sm:text-7xl lg:text-8xl"><?php echo e($school->tagline ?: 'Tumbuh tangguh, berkarya bersama.'); ?></h1>
                <div class="mt-9 flex flex-wrap gap-3"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school->registration_open): ?><a href="<?php echo e(route('register', ['school' => $school->id])); ?>" class="rounded-full bg-amber-300 px-7 py-3.5 font-bold text-slate-950">Daftar sebagai anggota</a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><a href="#agenda" class="rounded-full border border-white/50 px-7 py-3.5 font-bold">Lihat kegiatan</a></div>
            </div>
        </section>

        <section id="profil" class="px-5 py-20 lg:px-8"><div class="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[.8fr_1.2fr]">
            <div><p class="text-sm font-bold uppercase tracking-[.2em] text-[var(--school-color)]">Tentang gugus depan</p><h2 class="mt-3 text-4xl font-black tracking-tight">Pramuka di<br><?php echo e($school->name); ?></h2></div>
            <div><p class="text-xl leading-9 text-slate-600 dark:text-zinc-300"><?php echo e($school->profile ?: 'Kegiatan Pramuka kami menjadi ruang belajar yang menyenangkan untuk membangun kemandirian, kepemimpinan, kepedulian, dan semangat gotong royong peserta didik.'); ?></p>
                <dl class="mt-10 grid gap-4 sm:grid-cols-3"><div class="rounded-2xl bg-white p-5 dark:bg-zinc-900 dark:text-zinc-100 dark:border-zinc-700"><dt class="text-xs font-bold uppercase tracking-wider text-slate-400">NPSN</dt><dd class="mt-2 font-bold"><?php echo e($school->npsn); ?></dd></div><div class="rounded-2xl bg-white p-5 dark:bg-zinc-900 dark:text-zinc-100 dark:border-zinc-700"><dt class="text-xs font-bold uppercase tracking-wider text-slate-400">Jenjang</dt><dd class="mt-2 font-bold"><?php echo e($school->level ?: 'Sekolah'); ?></dd></div><div class="rounded-2xl bg-white p-5 dark:bg-zinc-900 dark:text-zinc-100 dark:border-zinc-700"><dt class="text-xs font-bold uppercase tracking-wider text-slate-400">Lokasi</dt><dd class="mt-2 font-bold"><?php echo e($school->city ?: '-'); ?></dd></div></dl>
            </div>
        </div></section>

        <section id="agenda" class="bg-emerald-950 px-5 py-20 text-white lg:px-8"><div class="mx-auto max-w-7xl"><div class="flex items-end justify-between"><div><p class="text-sm font-bold uppercase tracking-[.2em] text-amber-300">Tetap terhubung</p><h2 class="mt-3 text-4xl font-black">Pengumuman & agenda</h2></div></div>
            <div class="mt-10 grid gap-5 lg:grid-cols-2"><div class="grid gap-4"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $school->announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><article class="rounded-3xl bg-white/10 p-6"><p class="text-xs font-bold uppercase tracking-widest text-amber-300">Pengumuman · <?php echo e(optional($announcement->published_at)->translatedFormat('d M Y')); ?></p><h3 class="mt-3 text-xl font-bold"><?php echo e($announcement->title); ?></h3><p class="mt-3 line-clamp-3 text-sm leading-6 text-slate-300"><?php echo e(strip_tags($announcement->body)); ?></p><a href="<?php echo e(route('schools.announcements.show', [$school, $announcement->id])); ?>" class="mt-5 inline-flex font-bold text-amber-300">Baca pengumuman &rarr;</a></article><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?><div class="rounded-3xl border border-dashed border-white/20 p-8 text-slate-400">Belum ada pengumuman publik.</div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                <div class="grid gap-4"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $school->activities->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><article class="flex gap-5 rounded-3xl bg-white p-6 text-slate-900 dark:bg-zinc-900 dark:text-zinc-100 dark:border-zinc-700"><div class="grid size-16 shrink-0 place-items-center rounded-2xl bg-amber-300 text-center"><span class="text-2xl font-black leading-none"><?php echo e($activity->start_at->format('d')); ?></span><span class="text-[10px] font-bold uppercase"><?php echo e($activity->start_at->translatedFormat('M')); ?></span></div><div><h3 class="font-bold"><?php echo e($activity->title); ?></h3><p class="mt-2 text-sm text-slate-500 dark:text-zinc-400"><?php echo e($activity->start_at->format('H.i')); ?> · <?php echo e($activity->location ?: 'Lokasi menyusul'); ?></p><a href="<?php echo e(route('schools.activities.show', [$school, $activity->id])); ?>" class="mt-4 inline-flex text-sm font-bold text-emerald-800">Detail kegiatan &rarr;</a></div></article><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?><div class="rounded-3xl border border-dashed border-white/20 p-8 text-slate-400">Belum ada agenda publik.</div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
            </div>
        </div></section>

        <section id="dokumentasi" class="px-5 py-20 lg:px-8">
    <div class="mx-auto max-w-7xl">

        
        <p
            class="text-sm font-bold uppercase tracking-[.2em]
                   text-[var(--school-color)]"
        >
            Cerita dari lapangan
        </p>

        <h2 class="mt-3 text-4xl font-black">
            Dokumentasi kegiatan
        </h2>

        
        <div class="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $school->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                <article
                    class="group relative min-h-[340px]
                           overflow-hidden rounded-3xl
                           bg-[var(--school-color)]
                           text-white shadow-sm"
                >

                    
                    
                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activity->cover_image_url): ?>

                        <img
                            src="<?php echo e($activity->cover_image_url); ?>"
                            alt="Dokumentasi <?php echo e($activity->title); ?>"
                            loading="lazy"
                            class="absolute inset-0
                                   h-full w-full
                                   object-cover
                                   transition duration-700 ease-out
                                   group-hover:scale-105"
                        >

                        
                        <div
                            class="absolute inset-0
                                   bg-gradient-to-t
                                   from-black/90
                                   via-black/55
                                   to-black/10"
                        ></div>

                        
                        <div
                            class="absolute inset-0
                                   bg-[var(--school-color)]
                                   opacity-10"
                        ></div>

                    <?php else: ?>

                        
                        
                        
                        <div
                            class="absolute inset-0
                                   bg-[var(--school-color)]"
                        ></div>

                        <div
                            class="absolute -right-10 -top-10
                                   size-40 rounded-full
                                   border-[25px] border-white/10
                                   transition duration-500
                                   group-hover:scale-110"
                        ></div>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                    
                    
                    
                    <div
                        class="relative z-10 flex min-h-[340px]
                               flex-col justify-end p-7"
                    >

                        <p
                            class="text-xs font-bold uppercase
                                   tracking-widest text-amber-300"
                        >
                            <?php echo e($activity->activity_type ?: 'Kegiatan'); ?>

                            ·
                            <?php echo e($activity->start_at->translatedFormat('M Y')); ?>

                        </p>


                        <h3
                            class="mt-3 text-2xl font-black
                                   leading-tight"
                        >
                            <?php echo e($activity->title); ?>

                        </h3>


                        <?php
                            $documentationDescription =
                                $activity->journal?->activity_description
                                ?: $activity->description
                                ?: $activity->location;
                        ?>


                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($documentationDescription): ?>
                            <p
                                class="mt-3 line-clamp-2
                                       text-sm leading-6
                                       text-white/80"
                            >
                                <?php echo e($documentationDescription); ?>

                            </p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                        <a
                            href="<?php echo e(route(
                                'schools.documentation.show',
                                [$school, $activity->id]
                            )); ?>"
                            class="mt-5 inline-flex items-center
                                   gap-2 font-bold
                                   text-amber-300
                                   transition
                                   hover:text-amber-200"
                        >
                            Lihat dokumentasi

                            <span
                                aria-hidden="true"
                                class="transition-transform
                                       duration-200
                                       group-hover:translate-x-1"
                            >
                                &rarr;
                            </span>
                        </a>

                    </div>

                </article>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                <div
                    class="col-span-full
                           rounded-3xl
                           border border-dashed border-slate-300
                           p-12 text-center
                           text-slate-500
                           dark:border-zinc-700
                           dark:text-zinc-400"
                >
                    Dokumentasi kegiatan akan segera hadir.
                </div>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>
    </div>
</section>

        <section id="kontak" class="px-5 pb-20 lg:px-8"><div class="mx-auto grid max-w-7xl overflow-hidden rounded-[2rem] bg-amber-300 text-slate-900 lg:grid-cols-2"><div class="p-8 lg:p-12"><p class="text-sm font-bold uppercase tracking-[.2em] text-[var(--school-color)]">Hubungi kami</p><h2 class="mt-3 text-4xl font-black">Punya pertanyaan tentang Pramuka?</h2><p class="mt-5 max-w-md leading-7 text-slate-700">Pembina kami siap membantu informasi kegiatan dan pendaftaran anggota.</p><div class="mt-8 space-y-2 text-sm font-semibold"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school->phone): ?><p>Telepon · <?php echo e($school->phone); ?></p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school->email): ?><p>Email · <?php echo e($school->email); ?></p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><p>Alamat · <?php echo e($school->address ?: $school->city); ?></p></div></div><div class="grid gap-px bg-slate-900/10 sm:grid-cols-2"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $school->coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><div class="bg-white/60 p-8 text-slate-900 dark:bg-zinc-900 dark:text-zinc-100"><span class="grid size-12 place-items-center rounded-full bg-[var(--school-color)] font-bold text-white"><?php echo e(str($coach->name)->substr(0, 1)); ?></span><h3 class="mt-5 font-bold"><?php echo e($coach->name); ?></h3><p class="mt-1 text-sm text-slate-600 dark:text-zinc-300"><?php echo e($coach->position ?: 'Pembina Pramuka'); ?></p><?php ($contactEmail = filter_var($coach->user?->email, FILTER_VALIDATE_EMAIL) ? $coach->user->email : (filter_var($school->email, FILTER_VALIDATE_EMAIL) ? $school->email : null)); ?>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($contactEmail): ?><a href="mailto:<?php echo e($contactEmail); ?>?subject=<?php echo e(rawurlencode('Informasi Pramuka '.$school->name)); ?>" class="mt-5 inline-block text-sm font-bold text-[var(--school-color)] dark:text-emerald-300">Hubungi pembina &rarr;</a><?php else: ?><p class="mt-5 text-sm text-slate-500">Email kontak belum tersedia.</p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?><div class="col-span-full grid place-items-center p-10 text-sm text-slate-600 dark:text-zinc-300">Kontak pembina akan segera diperbarui.</div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div></div></section>
    </main>
    <footer class="bg-[var(--school-color)] px-5 py-10 text-white lg:px-8"><div class="mx-auto flex max-w-7xl flex-col justify-between gap-5 sm:flex-row"><p class="font-bold"><?php echo e($school->name); ?></p><div class="flex gap-5 text-sm text-white/70"><a href="<?php echo e(route('home')); ?>">SIMPRAM</a><a href="<?php echo e(route('login', ['school' => $school->slug])); ?>">Login anggota / pembina</a></div></div></footer>
    <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

</body>
</html>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/landing/school.blade.php ENDPATH**/ ?>