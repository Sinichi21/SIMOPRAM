<?php # [BlazeFolded]:{flux::menu.item}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/item.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::menu.item}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/item.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::menu.item}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/item.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::menu.separator}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/separator.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::menu.item}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/item.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::menu.item}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/item.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::menu.item}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/item.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::menu.item}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/item.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::menu}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/index.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::dropdown}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/dropdown.blade.php}:{1788140904} ?>
<nav aria-label="Navigasi area" <?php echo e($attributes->class('flex flex-wrap items-center gap-2 text-sm')); ?>>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
        <?php ob_start(); ?><ui-dropdown position="bottom end"  data-flux-dropdown>
    <?php ob_start(); ?>
            <?php if (!function_exists('_fd6425d9e0a8f955e87d1252ab959488')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/profile.blade.php', $__blaze->compiledPath.'/fd6425d9e0a8f955e87d1252ab959488.php'); require $__blaze->compiledPath.'/fd6425d9e0a8f955e87d1252ab959488.php'; } ?>
<?php $__blaze->pushData(['name' => auth()->user()->name,'initials' => auth()->user()->initials(),'circle' => true,'ariaLabel' => 'Buka menu profil','class' => 'max-w-56 border border-zinc-200 bg-white pe-2 dark:border-zinc-700 dark:bg-zinc-900']); ?>
<?php _fd6425d9e0a8f955e87d1252ab959488($__blaze, ['name' => auth()->user()->name,'initials' => auth()->user()->initials(),'circle' => true,'ariaLabel' => 'Buka menu profil','class' => 'max-w-56 border border-zinc-200 bg-white pe-2 dark:border-zinc-700 dark:bg-zinc-900'], [], ['name', 'initials', 'circle'], ['ariaLabel' => 'aria-label'], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            <?php ob_start(); ?><ui-menu
    class="[:where(&amp;)]:min-w-48 p-[.3125rem] rounded-lg shadow-xs border border-zinc-200 dark:border-zinc-600 bg-white dark:bg-zinc-700 focus:outline-hidden w-72 max-w-[calc(100vw-2rem)] rounded-2xl p-2 shadow-xl dark:bg-zinc-900"
    popover="manual"
    data-flux-menu
>
    <?php ob_start(); ?>
                <div class="flex items-center gap-3 rounded-xl bg-zinc-50 px-3 py-4 dark:bg-zinc-800">
                    <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::avatar", ['initials' => auth()->user()->initials(), 'circle' => true]); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php if (!function_exists('_a60d803aa23c89bfebe34f8773d51a0b')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/avatar/index.blade.php', $__blaze->compiledPath.'/a60d803aa23c89bfebe34f8773d51a0b.php'); require $__blaze->compiledPath.'/a60d803aa23c89bfebe34f8773d51a0b.php'; } ?>
<?php $__blaze->pushData(['initials' => auth()->user()->initials(),'circle' => true]); ?>
<?php _a60d803aa23c89bfebe34f8773d51a0b($__blaze, ['initials' => auth()->user()->initials(),'circle' => true], [], ['initials', 'circle'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
                    <div class="min-w-0">
                        <p class="truncate font-semibold text-zinc-900 dark:text-zinc-100"><?php echo e(auth()->user()->name); ?></p>
                        <p class="mt-1 truncate text-xs text-zinc-500 dark:text-zinc-400"><?php echo e(auth()->user()->email); ?></p>
                    </div>
                </div>
                <p class="px-3 pb-2 pt-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">Pindah area</p>
                <?php ob_start(); ?><a href="<?php echo e(route('home')); ?>" data-flux-menu-item="data-flux-menu-item" class="flex items-center px-2 py-1.5 w-full focus:outline-hidden select-none rounded-md text-start text-sm font-medium [&amp;[disabled]]:opacity-50 text-zinc-800 data-active:bg-zinc-50 dark:text-white dark:data-active:bg-zinc-600 **:data-flux-menu-item-icon:text-zinc-400 dark:**:data-flux-menu-item-icon:text-white/60 [&amp;[data-active]_[data-flux-menu-item-icon]]:text-current">
        <div class="w-7 hidden [[data-flux-menu]:has(>[data-flux-menu-item-has-icon])_&]:block"></div>
    
    <?php ob_start(); ?>Global Area<?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><a href="<?php echo e($navigationSchool ? route('schools.landing', $navigationSchool) : route('home').'#sekolah'); ?>" data-flux-menu-item="data-flux-menu-item" class="flex items-center px-2 py-1.5 w-full focus:outline-hidden select-none rounded-md text-start text-sm font-medium [&amp;[disabled]]:opacity-50 text-zinc-800 data-active:bg-zinc-50 dark:text-white dark:data-active:bg-zinc-600 **:data-flux-menu-item-icon:text-zinc-400 dark:**:data-flux-menu-item-icon:text-white/60 [&amp;[data-active]_[data-flux-menu-item-icon]]:text-current">
        <div class="w-7 hidden [[data-flux-menu]:has(>[data-flux-menu-item-has-icon])_&]:block"></div>
    
    <?php ob_start(); ?>School Area<?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><a href="<?php echo e(route('dashboard')); ?>" data-flux-menu-item="data-flux-menu-item" class="flex items-center px-2 py-1.5 w-full focus:outline-hidden select-none rounded-md text-start text-sm font-medium [&amp;[disabled]]:opacity-50 text-zinc-800 data-active:bg-zinc-50 dark:text-white dark:data-active:bg-zinc-600 **:data-flux-menu-item-icon:text-zinc-400 dark:**:data-flux-menu-item-icon:text-white/60 [&amp;[data-active]_[data-flux-menu-item-icon]]:text-current">
        <div class="w-7 hidden [[data-flux-menu]:has(>[data-flux-menu-item-has-icon])_&]:block"></div>
    
    <?php ob_start(); ?><?php echo e($dashboardLabel); ?><?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><div class="-mx-[.3125rem] my-[.3125rem] h-px"  data-flux-menu-separator>
    <div data-orientation="horizontal" role="none" class="border-0 [print-color-adjust:exact] bg-zinc-800/15 dark:bg-white/20 h-px w-full dark:bg-zinc-600!" data-flux-separator></div>
</div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('landing.manage')): ?>
                    <?php ob_start(); ?><a href="<?php echo e(route('settings.landing-content')); ?>" data-flux-menu-item="data-flux-menu-item" class="flex items-center px-2 py-1.5 w-full focus:outline-hidden select-none rounded-md text-start text-sm font-medium [&amp;[disabled]]:opacity-50 text-zinc-800 data-active:bg-zinc-50 dark:text-white dark:data-active:bg-zinc-600 **:data-flux-menu-item-icon:text-zinc-400 dark:**:data-flux-menu-item-icon:text-white/60 [&amp;[data-active]_[data-flux-menu-item-icon]]:text-current">
        <div class="w-7 hidden [[data-flux-menu]:has(>[data-flux-menu-item-has-icon])_&]:block"></div>
    
    <?php ob_start(); ?>Edit landing page<?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?>
                <?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($navigationSchool): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('school-landing.manage', $navigationSchool)): ?>
                        <?php ob_start(); ?><a href="<?php echo e(route('settings.tenant-content', $navigationSchool)); ?>" data-flux-menu-item="data-flux-menu-item" class="flex items-center px-2 py-1.5 w-full focus:outline-hidden select-none rounded-md text-start text-sm font-medium [&amp;[disabled]]:opacity-50 text-zinc-800 data-active:bg-zinc-50 dark:text-white dark:data-active:bg-zinc-600 **:data-flux-menu-item-icon:text-zinc-400 dark:**:data-flux-menu-item-icon:text-white/60 [&amp;[data-active]_[data-flux-menu-item-icon]]:text-current">
        <div class="w-7 hidden [[data-flux-menu]:has(>[data-flux-menu-item-has-icon])_&]:block"></div>
    
    <?php ob_start(); ?>Edit halaman tenant<?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?>
                    <?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php ob_start(); ?><a href="<?php echo e(route('profile.edit')); ?>" data-flux-menu-item="data-flux-menu-item" class="flex items-center px-2 py-1.5 w-full focus:outline-hidden select-none rounded-md text-start text-sm font-medium [&amp;[disabled]]:opacity-50 text-zinc-800 data-active:bg-zinc-50 dark:text-white dark:data-active:bg-zinc-600 **:data-flux-menu-item-icon:text-zinc-400 dark:**:data-flux-menu-item-icon:text-white/60 [&amp;[data-active]_[data-flux-menu-item-icon]]:text-current">
        <div class="w-7 hidden [[data-flux-menu]:has(>[data-flux-menu-item-has-icon])_&]:block"></div>
    
    <?php ob_start(); ?>Profil saya<?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php ob_start(); ?><button type="submit" class="flex items-center px-2 py-1.5 w-full focus:outline-hidden select-none rounded-md text-start text-sm font-medium [&amp;[disabled]]:opacity-50 text-zinc-800 data-active:text-red-600 data-active:bg-red-50 dark:text-white dark:data-active:bg-red-400/20 dark:data-active:text-red-400 **:data-flux-menu-item-icon:text-zinc-400 dark:**:data-flux-menu-item-icon:text-white/60 [&amp;[data-active]_[data-flux-menu-item-icon]]:text-current w-full" data-flux-menu-item="data-flux-menu-item">
        <div class="w-7 hidden [[data-flux-menu]:has(>[data-flux-menu-item-has-icon])_&]:block"></div>
    
    <?php ob_start(); ?>Keluar<?php echo trim(ob_get_clean()); ?>

    </button>
<?php echo ltrim(ob_get_clean()); ?>
                </form>
            <?php echo trim(ob_get_clean()); ?>

</ui-menu>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

</ui-dropdown>
<?php echo ltrim(ob_get_clean()); ?>
    <?php else: ?>
        <a href="<?php echo e(route('home')); ?>" <?php if(request()->routeIs('home')): ?> aria-current="page" <?php endif; ?> class="rounded-full border border-zinc-200 px-3 py-2 font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">Global Area</a>
        <a href="<?php echo e($navigationSchool ? route('schools.landing', $navigationSchool) : route('home').'#sekolah'); ?>" <?php if(request()->routeIs('schools.*')): ?> aria-current="page" <?php endif; ?> class="rounded-full border border-zinc-200 px-3 py-2 font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">School Area</a>
        <a href="<?php echo e(route('login', $navigationSchool ? ['school' => $navigationSchool->slug] : [])); ?>" class="rounded-full bg-emerald-800 px-4 py-2 font-bold text-white">Masuk</a>
        <a href="<?php echo e(route('register', $navigationSchool ? ['school' => $navigationSchool->id] : [])); ?>" class="rounded-full bg-amber-300 px-4 py-2 font-bold text-emerald-950">Daftar</a>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</nav>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/components/area-navigation.blade.php ENDPATH**/ ?>