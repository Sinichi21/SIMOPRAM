<?php # [BlazeFolded]:{flux::sidebar.collapse}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/collapse.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.header}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/header.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::icon.building-library}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/building-library.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::spacer}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/spacer.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/index.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::sidebar.toggle}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/toggle.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::spacer}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/spacer.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::header}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/header.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::toast}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/toast/index.blade.php}:{1788140904} ?>
<?php # [BlazeFolded]:{flux::toast.group}:{D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/toast/group.blade.php}:{1788140904} ?>
<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body class="simpram-app min-h-screen bg-[#f7f5ee] text-zinc-900 dark:bg-zinc-950 dark:text-zinc-100">

    <?php
        $currentSchoolId = app(\App\Support\SchoolContext::class)->id();
        $currentUser = auth()->user();
        $hasActiveSchool = $currentSchoolId !== null;
        $isStudent = $currentUser ?->hasRole('student') ?? false;
        $isCoach = $currentUser ?->hasRole('coach') ?? false;
        $contentSchool = request()->route('school') instanceof \App\Models\School
            ? request()->route('school')
            : ($activeSchool ?? $schools->firstWhere('id', session('active_school_id')));
    ?>

    

    <?php ob_start(); ?><ui-sidebar-toggle class="z-20 fixed inset-0 bg-black/10 hidden data-flux-sidebar-on-mobile:not-data-flux-sidebar-collapsed-mobile:block" data-flux-sidebar-backdrop></ui-sidebar-toggle>

<ui-sidebar
    class="[grid-area:sidebar] z-1 flex flex-col gap-4 [:where(&amp;)]:w-64 p-4 data-flux-sidebar-collapsed-desktop:w-14 data-flux-sidebar-collapsed-desktop:px-2 data-flux-sidebar-collapsed-desktop:cursor-e-resize rtl:data-flux-sidebar-collapsed-desktop:cursor-w-resize max-lg:data-flux-sidebar-cloak:hidden data-flux-sidebar-on-mobile:data-flux-sidebar-collapsed-mobile:-translate-x-full data-flux-sidebar-on-mobile:data-flux-sidebar-collapsed-mobile:rtl:translate-x-full z-20! data-flux-sidebar-on-mobile:start-0! data-flux-sidebar-on-mobile:fixed! data-flux-sidebar-on-mobile:top-0! data-flux-sidebar-on-mobile:min-h-dvh! data-flux-sidebar-on-mobile:max-h-dvh! max-h-dvh overflow-y-auto overscroll-contain border-e border-zinc-200 bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-900" x-init="$el.classList.add(&#039;transition-transform&#039;)" x-data="{ hasActiveSchool: <?php echo e($hasActiveSchool ? 'true' : 'false'); ?> }" x-on:click.capture="if (! hasActiveSchool && $event.target.closest('[data-school-menu]')) {
                $event.preventDefault();
                $event.stopPropagation();
                $flux.toast({
                    variant: 'warning',
                    heading: 'Sekolah belum dipilih',
                    text: 'Pilih sekolah aktif terlebih dahulu.'
                });
            }"
     collapsible="mobile"          sticky     x-data
    data-flux-sidebar-cloak
    data-flux-sidebar
>
    <?php ob_start(); ?>

        
        <?php ob_start(); ?><div class="flex items-center justify-between gap-2 min-h-10" data-flux-sidebar-header>
    <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal7b17d80ff7900603fe9e5f0b453cc7c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b17d80ff7900603fe9e5f0b453cc7c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo','data' => ['sidebar' => true,'href' => ''.e(route('dashboard')).'','wire:navigate' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['sidebar' => true,'href' => ''.e(route('dashboard')).'','wire:navigate' => true]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b17d80ff7900603fe9e5f0b453cc7c3)): ?>
<?php $attributes = $__attributesOriginal7b17d80ff7900603fe9e5f0b453cc7c3; ?>
<?php unset($__attributesOriginal7b17d80ff7900603fe9e5f0b453cc7c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b17d80ff7900603fe9e5f0b453cc7c3)): ?>
<?php $component = $__componentOriginal7b17d80ff7900603fe9e5f0b453cc7c3; ?>
<?php unset($__componentOriginal7b17d80ff7900603fe9e5f0b453cc7c3); ?>
<?php endif; ?>

            <?php ob_start(); ?><ui-sidebar-toggle class="w-10 h-8 shrink-0 flex items-center justify-center in-data-flux-sidebar-collapsed-desktop:opacity-0 in-data-flux-sidebar-collapsed-desktop:absolute in-data-flux-sidebar-collapsed-desktop:in-data-flux-sidebar-active:opacity-100  lg:hidden" data-flux-sidebar-collapse>
    <ui-tooltip position="right center"  data-flux-tooltip >
        <button type="button" class="size-10 relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none text-sm rounded-lg inline-flex  bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white in-data-flux-sidebar-collapsed-desktop:cursor-e-resize rtl:in-data-flux-sidebar-collapsed-desktop:cursor-w-resize [&amp;[collapsible=&quot;mobile&quot;]]:in-data-flux-sidebar-on-desktop:hidden rtl:rotate-180">
            <svg class="text-zinc-500 dark:text-zinc-400" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.5 3.75V16.25M3.4375 16.25H16.5625C17.08 16.25 17.5 15.83 17.5 15.3125V4.6875C17.5 4.17 17.08 3.75 16.5625 3.75H3.4375C2.92 3.75 2.5 4.17 2.5 4.6875V15.3125C2.5 15.83 2.92 16.25 3.4375 16.25Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
        </button>

                    <div popover="manual" class="relative py-2 px-2.5 rounded-md text-xs text-white font-medium bg-zinc-800 dark:bg-zinc-700 dark:border dark:border-white/10 p-0 overflow-visible" data-flux-tooltip-content>
    Toggle sidebar

    </div>
            </ui-tooltip>
</ui-sidebar-toggle>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

</div><?php echo ltrim(ob_get_clean()); ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isStudent): ?>

            

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeSchool): ?>

                <div class="px-2 pb-2">

                    <div
                        class="rounded-xl border
                            border-zinc-200
                            bg-white px-3 py-3
                            dark:border-zinc-700
                            dark:bg-zinc-800"
                    >

                        <div
                            class="text-[11px] font-medium
                                uppercase tracking-wide
                                text-zinc-400"
                        >
                            Pangkalan
                        </div>

                        <div
                            class="mt-1 truncate
                                text-sm font-semibold
                                text-zinc-900
                                dark:text-white"
                            title="<?php echo e($activeSchool->name); ?>"
                        >
                            <?php echo e($activeSchool->name); ?>

                        </div>

                    </div>

                </div>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                <?php ob_start(); ?><div class="flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden grid" data-flux-sidebar-group>
        <div class="px-3 py-2">
            <div class="text-sm text-zinc-400 font-medium leading-none">Beranda</div>
        </div>

        <div class="flex flex-col">
            <?php ob_start(); ?>

                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'home','href' => route('dashboard'),'current' => request()->routeIs(
                            'dashboard'
                        ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Dashboard
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

        </div>
    </div>
<?php echo ltrim(ob_get_clean()); ?>

            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>


            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                <?php ob_start(); ?><div class="flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden grid" data-flux-sidebar-group>
        <div class="px-3 py-2">
            <div class="text-sm text-zinc-400 font-medium leading-none">Kegiatan Saya</div>
        </div>

        <div class="flex flex-col">
            <?php ob_start(); ?>

                    
                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'calendar-days','href' => e(route('dashboard')).'#agenda']; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Agenda
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendances.self')): ?>

                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'map-pin','href' => route(
                                'attendances.self'
                            ),'current' => request()->routeIs(
                                'attendances.self'
                            ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Absensi Saya
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                    <?php endif; ?>


                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'clock','href' => e(route('dashboard')).'#riwayat']; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Riwayat Kehadiran
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

        </div>
    </div>
<?php echo ltrim(ob_get_clean()); ?>

            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>


            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                <?php ob_start(); ?><div class="flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden grid" data-flux-sidebar-group>
        <div class="px-3 py-2">
            <div class="text-sm text-zinc-400 font-medium leading-none">Perkembangan Saya</div>
        </div>

        <div class="flex flex-col">
            <?php ob_start(); ?>

                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'academic-cap','href' => route(
                            'student.grades'
                        ),'current' => request()->routeIs(
                            'student.grades'
                        ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Nilai Saya
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>


                     <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'clipboard-document-check','href' => route(
                            'student.skills'
                        ),'current' => request()->routeIs(
                            'student.skills'
                        ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Keterampilan Saya
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>


                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'chart-bar','href' => route(
                            'student.grade-history'
                        ),'current' => request()->routeIs(
                            'student.grade-history'
                        ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Riwayat Nilai
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>


                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'identification','href' => route(
                            'student.scout-profile'
                        ),'current' => request()->routeIs(
                            'student.scout-profile'
                        ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Profil Pramuka
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

        </div>
    </div>
<?php echo ltrim(ob_get_clean()); ?>

            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>


            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                <?php ob_start(); ?><div class="flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden grid" data-flux-sidebar-group>
        <div class="px-3 py-2">
            <div class="text-sm text-zinc-400 font-medium leading-none">Informasi</div>
        </div>

        <div class="flex flex-col">
            <?php ob_start(); ?>

                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'megaphone','href' => route(
                            'announcements.my'
                        ),'current' => request()->routeIs(
                            'announcements.my'
                        ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Pengumuman
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'document-text','href' => route(
                            'student.documents'
                        ),'current' => request()->routeIs(
                            'student.documents'
                        ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Dokumen Saya
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

        </div>
    </div>
<?php echo ltrim(ob_get_clean()); ?>

            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>


            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                <?php ob_start(); ?><div class="flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden grid" data-flux-sidebar-group>
        <div class="px-3 py-2">
            <div class="text-sm text-zinc-400 font-medium leading-none">Akun</div>
        </div>

        <div class="flex flex-col">
            <?php ob_start(); ?>

                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'bell-alert','href' => route(
                            'notification-settings.manage'
                        ),'current' => request()->routeIs(
                            'notification-settings.*'
                        ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Pengaturan Notifikasi
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

        </div>
    </div>
<?php echo ltrim(ob_get_clean()); ?>

            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>


        <?php elseif($isCoach): ?>

        
            

            <div
                class="mx-2 mb-3
                    rounded-2xl
                    border border-zinc-200
                    bg-white p-3
                    shadow-sm
                    dark:border-zinc-800
                    dark:bg-zinc-900"
            >

                <div
                    class="mb-2 flex
                        items-center gap-2"
                >
                    <div
                        class="flex size-8
                            items-center
                            justify-center
                            rounded-lg
                            bg-emerald-50
                            text-emerald-600
                            dark:bg-emerald-950/50
                            dark:text-emerald-400"
                    >
                        <?php ob_start(); ?><svg class="shrink-0 [:where(&amp;)]:size-6 size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M12 21v-8.25M15.75 21v-8.25M8.25 21v-8.25M3 9l9-6 9 6m-1.5 12V10.332A48.36 48.36 0 0 0 12 9.75c-2.551 0-5.056.2-7.5.582V21M3 21h18M12 6.75h.008v.008H12V6.75Z"/>
</svg>

        <?php echo ltrim(ob_get_clean()); ?>
                    </div>

                    <div class="min-w-0">
                        <div
                            class="text-[10px]
                                font-semibold
                                uppercase
                                tracking-wider
                                text-zinc-400"
                        >
                            Sekolah Aktif
                        </div>

                        <div
                            class="text-xs
                                text-zinc-500"
                        >
                            Area Pembina
                        </div>
                    </div>
                </div>


                
                <form
                    method="POST"
                    action="<?php echo e(route(
                            'school.switch'
                        )); ?>"
                >
                    <?php echo csrf_field(); ?>

                    <select
                        name="school_id"
                        onchange="this.form.submit()"
                        class="w-full
                            rounded-xl
                            border border-zinc-200
                            bg-zinc-50
                            px-3 py-2.5
                            text-sm
                            font-medium
                            text-zinc-800
                            outline-none
                            transition
                            focus:border-emerald-500
                            focus:ring-2
                            focus:ring-emerald-500/10
                            dark:border-zinc-700
                            dark:bg-zinc-800
                            dark:text-zinc-100"
                    >

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                            <option
                                value="<?php echo e($school->id); ?>"
                                <?php if(
                                    $currentSchoolId
                                    ===
                                    $school->id
                                ): echo 'selected'; endif; ?>
                            >
                                <?php echo e($school->name); ?>

                            </option>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                    </select>

                </form>

            </div>


            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                <?php ob_start(); ?><div class="flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden grid" data-flux-sidebar-group>
        <div class="px-3 py-2">
            <div class="text-sm text-zinc-400 font-medium leading-none">Beranda</div>
        </div>

        <div class="flex flex-col">
            <?php ob_start(); ?>

                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'home','href' => route('dashboard'),'current' => 
                            request()->routeIs(
                                'dashboard'
                            )
                        ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Dashboard
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

        </div>
    </div>
<?php echo ltrim(ob_get_clean()); ?>

            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>


            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                'activities.view',
                'attendance_sessions.view',
                'journals.view'
            ])): ?>

                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed'
                            => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Kegiatan','expandable' => true,'expanded' => 
                            request()->routeIs(
                                'activities.*',
                                'attendances.*',
                                'journals.*'
                            )
                        ,'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activities.view')): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'calendar-days','href' => route(
                                    'activities.index'
                                ),'current' => 
                                    request()->routeIs(
                                        'activities.*'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Agenda & Kegiatan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_sessions.view')): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'clipboard-document-check','href' => route(
                                    'attendances.index'
                                ),'current' => 
                                    request()->routeIs(
                                        'attendances.index',
                                        'attendances.manage'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Absensi
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('journals.view')): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'document-text','href' => route(
                                    'journals.index'
                                ),'current' => 
                                    request()->routeIs(
                                        'journals.*'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Jurnal Kegiatan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>

                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>

            <?php endif; ?>


            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                'assessments.scores.view',
                'activity_assessments.view',
                'assessment_sync.view',
                // 'assessment_audit.view',
                'semester_closures.view'
            ])): ?>

                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed'
                            => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Penilaian','expandable' => true,'expanded' => 
                            request()->routeIs(
                                'assessments.scores',
                                'activity-assessments.*'
                            )
                        ,'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                            'assessments.scores.view'
                        )): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'pencil-square','href' => route(
                                    'assessments.scores'
                                ),'current' => 
                                    request()->routeIs(
                                        'assessments.scores'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Input Nilai
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                            'activity_assessments.view'
                        )): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'academic-cap','href' => route(
                                    'activity-assessments.index'
                                ),'current' => 
                                    request()->routeIs(
                                        'activity-assessments.*'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Penilaian Kegiatan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assessment_sync.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'arrow-path','href' => route('assessment-sync.index'),'current' => request()->routeIs('assessment-sync.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Sinkronisasi Penilaian
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('semester_closures.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'lock-closed','href' => route('semester-closures.index'),'current' => request()->routeIs('semester-closures.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Kunci Semester
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assessments.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['dataSchoolMenu' => true,'class' => \Illuminate\Support\Arr::toCssClasses([
                                    'opacity-60 cursor-not-allowed' => ! $hasActiveSchool,
                                ]),'icon' => 'clipboard-document-check','href' => route('assessments.settings'),'current' => request()->routeIs('assessments.settings'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Pengaturan Penilaian
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['dataSchoolMenu', 'class', 'href', 'current', 'wire:navigate'], ['dataSchoolMenu' => 'data-school-menu'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>

            <?php endif; ?>


            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                'students.view',
                'scout_units.view'
            ])): ?>

                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed'
                            => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Data Binaan','expandable' => true,'expanded' => 
                            request()->routeIs(
                                'students.*',
                                'scout-units.*'
                            )
                        ,'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('students.view')): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'users','href' => route(
                                    'students.index'
                                ),'current' => 
                                    request()->routeIs(
                                        'students.*'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Siswa
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('scout_units.view')): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'rectangle-group','href' => route(
                                    'scout-units.index'
                                ),'current' => 
                                    request()->routeIs(
                                        'scout-units.*'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Regu / Barung
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>

                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>

            <?php endif; ?>


            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                'reports.grades.view',
                'reports.attendance.view',
                'reports.lpj.view'
            ])): ?>

                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed'
                            => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Laporan','expandable' => true,'expanded' => 
                            request()->routeIs(
                                'reports.grades',
                                'reports.attendance',
                                'reports.lpj*'
                            )
                        ,'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                            'reports.grades.view'
                        )): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'academic-cap','href' => route(
                                    'reports.grades'
                                ),'current' => 
                                    request()->routeIs(
                                        'reports.grades'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Rekap Nilai
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                            'reports.attendance.view'
                        )): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'clipboard-document-list','href' => route(
                                    'reports.attendance'
                                ),'current' => 
                                    request()->routeIs(
                                        'reports.attendance'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Rekap Absensi
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.lpj.view')): ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'document-text','href' => route(
                                    'reports.lpj'
                                ),'current' => 
                                    request()->routeIs(
                                        'reports.lpj*'
                                    )
                                ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                LPJ Kegiatan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php endif; ?>

                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>

            <?php endif; ?>


            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                    'opacity-60 [&_*]:cursor-not-allowed'
                        => ! $hasActiveSchool,
                ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Informasi','expandable' => true,'expanded' => 
                        request()->routeIs(
                            'announcements.*'
                        )
                    ,'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('announcements.view')): ?>

                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'megaphone','href' => route(
                                'announcements.index'
                            ),'current' => 
                                request()->routeIs(
                                    'announcements.index'
                                )
                            ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Kelola Pengumuman
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                    <?php endif; ?>


                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'bell','href' => route(
                            'announcements.my'
                        ),'current' => 
                            request()->routeIs(
                                'announcements.my'
                            )
                        ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Pengumuman Saya
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>

            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>


            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>

                <?php ob_start(); ?><div class="flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden grid" data-flux-sidebar-group>
        <div class="px-3 py-2">
            <div class="text-sm text-zinc-400 font-medium leading-none">Akun</div>
        </div>

        <div class="flex flex-col">
            <?php ob_start(); ?>

                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'bell','href' => route(
                            'notification-settings.manage'
                        ),'current' => 
                            request()->routeIs(
                                'notification-settings.*'
                            )
                        ,'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Pengaturan Notifikasi
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                <?php echo trim(ob_get_clean()); ?>

        </div>
    </div>
<?php echo ltrim(ob_get_clean()); ?>

            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>


        <?php else: ?>

            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => __('Menu Utama'),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'home','href' => route('dashboard'),'current' => request()->routeIs('dashboard'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Dashboard
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'chat-bubble-left-right','href' => route('complaints.index'),'current' => request()->routeIs('complaints.index', 'complaints.show'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Pengaduan
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['heading'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>

            

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($currentUser && app(\App\Services\GlobalActivityAccess::class)->canEnter($currentUser)): ?>
                <?php ob_start(); ?><div class="flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden grid" data-flux-sidebar-group>
        <div class="px-3 py-2">
            <div class="text-sm text-zinc-400 font-medium leading-none">Informasi Umum</div>
        </div>

        <div class="flex flex-col">
            <?php ob_start(); ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($currentUser->isSuperAdmin()): ?><?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['href' => route('admin.public-announcements'),'current' => request()->routeIs('admin.public-announcements'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>Pengumuman Umum<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['href' => route('admin.public-activities'),'current' => request()->routeIs('admin.public-activities'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>Kegiatan Umum<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['href' => route('admin.public-assessments'),'current' => request()->routeIs('admin.public-assessments'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>Penilaian Umum<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

        </div>
    </div>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['href' => route('activity-access.mine'),'current' => request()->routeIs('activity-access.mine')]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>Kegiatan Umum Saya<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
            <form
                method="POST"
                action="<?php echo e(route('school.switch')); ?>"
                class="px-2"
            >
                <?php echo csrf_field(); ?>

                <label class="mb-1 block text-xs font-medium text-zinc-500">
                    Sekolah Aktif
                </label>

                <select
                    name="school_id"
                    onchange="this.form.submit()"
                    class="w-full rounded-lg border border-zinc-300 bg-white px-3 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-900"
                >
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($currentUser && $currentUser->isSuperAdmin()): ?>
                        <option
                            value="global"
                            <?php if($currentSchoolId === null): echo 'selected'; endif; ?>
                        >
                            🌐 Semua Sekolah / Global
                        </option>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <option
                            value="<?php echo e($school->id); ?>"
                            <?php if($currentSchoolId === $school->id): echo 'selected'; endif; ?>
                        >
                            <?php echo e($school->name); ?>

                        </option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>
            </form>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeSchool): ?>
                <div
                    class="mx-2 mt-3 rounded-lg border border-zinc-200 bg-white px-3 py-2 dark:border-zinc-700 dark:bg-zinc-800"
                >
                    <div class="text-xs text-zinc-500 dark:text-zinc-400">
                        Sedang mengelola
                    </div>

                    <div
                        class="mt-1 truncate text-sm font-semibold text-zinc-900 dark:text-white"
                        title="<?php echo e($activeSchool->name); ?>"
                    >
                        <?php echo e($activeSchool->name); ?>

                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['activities.view', 'attendance_sessions.view', 'journals.view', 'announcements.view'])): ?>
                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed' => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Kegiatan','expandable' => true,'expanded' => request()->routeIs(
                            'activities.*',
                            'attendances.index',
                            'journals.*',
                            'announcements.index',
                            'announcements.create',
                            'announcements.edit'
                        ),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activities.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'calendar-days','href' => route('activities.index'),'current' => request()->routeIs('activities.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Agenda / Kegiatan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_sessions.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'clipboard-document-check','href' => route('attendances.index'),'current' => request()->routeIs('attendances.index'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Absensi
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('journals.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'document-text','href' => route('journals.index'),'current' => request()->routeIs('journals.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Jurnal Kegiatan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('announcements.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'megaphone','href' => route('announcements.index'),'current' => request()->routeIs(
                                    'announcements.index',
                                    'announcements.create',
                                    'announcements.edit'
                                ),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Pengumuman
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>
                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?>

            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                'assessments.scores.view',
                'activity_assessments.view',
                'assessment_sync.view',
                'assessment_audit.view',
                'semester_closures.view'
            ])): ?>
                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed' => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Penilaian','expandable' => true,'expanded' => request()->routeIs(
                            'assessments.scores',
                            'activity-assessments.*',
                            'assessment-sync.*',
                            'assessment-audit.*',
                            'semester-closures.*'
                        ),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assessments.scores.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'pencil-square','href' => route('assessments.scores'),'current' => request()->routeIs('assessments.scores'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Input Nilai
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activity_assessments.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'clipboard-document-check','href' => route('activity-assessments.index'),'current' => request()->routeIs('activity-assessments.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Penilaian Kegiatan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assessment_sync.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'arrow-path','href' => route('assessment-sync.index'),'current' => request()->routeIs('assessment-sync.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Sinkronisasi Penilaian
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assessment_audit.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'document-magnifying-glass','href' => route('assessment-audit.index'),'current' => request()->routeIs('assessment-audit.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Audit Penilaian
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('semester_closures.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'lock-closed','href' => route('semester-closures.index'),'current' => request()->routeIs('semester-closures.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Kunci Semester
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>
                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?>

            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                'academic_years.view',
                'semesters.view',
                'classrooms.view',
                'students.view',
                'coaches.view',
                'gudep.view',
                'scout_units.view'
            ])): ?>
                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed' => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Data Sekolah','expandable' => true,'expanded' => request()->routeIs(
                            'academic-years.*',
                            'semesters.*',
                            'classrooms.*',
                            'students.*',
                            'coaches.*',
                            'scout-groups.*',
                            'scout-units.*'
                        ),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('academic_years.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'calendar-days','href' => route('academic-years.index'),'current' => request()->routeIs('academic-years.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Tahun Ajaran
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('semesters.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'calendar','href' => route('semesters.index'),'current' => request()->routeIs('semesters.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Semester
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('classrooms.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'academic-cap','href' => route('classrooms.index'),'current' => request()->routeIs('classrooms.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Kelas
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('students.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'users','href' => route('students.index'),'current' => request()->routeIs('students.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Siswa
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coaches.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'user-group','href' => route('coaches.index'),'current' => request()->routeIs('coaches.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Pembina
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gudep.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'flag','href' => route('scout-groups.index'),'current' => request()->routeIs('scout-groups.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Gugus Depan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('scout_units.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'rectangle-group','href' => route('scout-units.index'),'current' => request()->routeIs('scout-units.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Regu / Barung
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>
                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?>

            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['letters.view', 'report_verifications.view', 'letters.templates'])): ?>
                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed' => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Persuratan','expandable' => true,'expanded' => (
                            request()->routeIs('letters.*')
                            && ! request()->routeIs('letters.settings')
                        ) || request()->routeIs('reports.published-documents.*'),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('letters.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'inbox-arrow-down','href' => route('letters.incoming'),'current' => request()->routeIs('letters.incoming'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Surat Masuk
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'paper-airplane','href' => route('letters.outgoing'),'current' => request()->routeIs('letters.outgoing'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Surat Keluar
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report_verifications.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'document-check','href' => route('reports.published-documents.index'),'current' => request()->routeIs('reports.published-documents.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Dokumen Terbit
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('letters.templates')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'document-text','href' => route('letters.templates'),'current' => request()->routeIs('letters.templates'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Template Surat
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>
                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?>

            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['reports.grades.view', 'reports.attendance.view', 'reports.lpj.view'])): ?>
                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed' => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Laporan','expandable' => true,'expanded' => request()->routeIs(
                            'reports.grades',
                            'reports.attendance',
                            'reports.lpj*'
                        ),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.grades.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'academic-cap','href' => route('reports.grades'),'current' => request()->routeIs('reports.grades'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Rekap Nilai
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.attendance.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'clipboard-document-list','href' => route('reports.attendance'),'current' => request()->routeIs('reports.attendance'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Rekap Absensi
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.lpj.view')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'document-text','href' => route('reports.lpj'),'current' => request()->routeIs('reports.lpj*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                LPJ Kegiatan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>
                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?>

            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user_approvals.manage', 'coach_accounts.manage', 'student_accounts.manage'])): ?>
                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                        'opacity-60 [&_*]:cursor-not-allowed' => ! $hasActiveSchool,
                    ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Manajemen Pengguna','expandable' => true,'expanded' => request()->routeIs(
                            'user-approvals.*',
                            'coach-accounts.*',
                            'student-accounts.*'
                        ),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_approvals.manage')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'users','href' => route('user-approvals.index'),'current' => request()->routeIs('user-approvals.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Akun dan Persetujuan
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coach_accounts.manage')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'user-group','href' => route('coach-accounts.index'),'current' => request()->routeIs('coach-accounts.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Akun Pembina
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('student_accounts.manage')): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'users','href' => route('student-accounts.index'),'current' => request()->routeIs('student-accounts.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Akun Siswa
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>
                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?>

            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto <?php echo e(\Illuminate\Support\Arr::toCssClasses([
                    'opacity-60 [&_*]:cursor-not-allowed' => ! $hasActiveSchool,
                ])); ?>" data-school-menu="data-school-menu" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Informasi Saya','expandable' => true,'expanded' => request()->routeIs(
                        'attendances.self',
                        'announcements.my'
                    ),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendances.self')): ?>
                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'map-pin','href' => route('attendances.self'),'current' => request()->routeIs('attendances.self'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Absensi Saya
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                    <?php endif; ?>

                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'bell','href' => route('announcements.my'),'current' => request()->routeIs('announcements.my'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Pengumuman Saya
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>

            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('schools.manage')): ?>
                <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                    <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Administrasi Sistem','expandable' => true,'expanded' => request()->routeIs(
                            'schools.*',
                            'school-registrations.*',
                            'activity-logs.*'
                        ),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'building-office-2','href' => route('schools.index'),'current' => request()->routeIs('schools.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Data Sekolah
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($currentUser?->isSuperAdmin()): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['href' => route('school-registrations.index'),'current' => request()->routeIs('school-registrations.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Permohonan Sekolah
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['href' => route('activity-logs.index'),'current' => request()->routeIs('activity-logs.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Log Aktivitas
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?>

            

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                <?php if (!function_exists('_e5289dcad7f1dc2d6a8251214164a93d')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php', $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'); require $__blaze->compiledPath.'/e5289dcad7f1dc2d6a8251214164a93d.php'; } ?>
<?php if (isset($__slotse5289dcad7f1dc2d6a8251214164a93d)) { $__slotsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__slotse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php if (isset($__attrse5289dcad7f1dc2d6a8251214164a93d)) { $__attrsStacke5289dcad7f1dc2d6a8251214164a93d[] = $__attrse5289dcad7f1dc2d6a8251214164a93d; } ?>
<?php $__attrse5289dcad7f1dc2d6a8251214164a93d = ['heading' => 'Pengaturan','expandable' => true,'expanded' => request()->routeIs(
                        'notification-settings.*',
                        'settings.*',
                        'assessments.settings',
                        'letters.settings'
                    ),'class' => 'grid']; ?>
<?php $__slotse5289dcad7f1dc2d6a8251214164a93d = []; ?>
<?php $__blaze->pushData($__attrse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php ob_start(); ?>
                    <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'bell-alert','href' => route('notification-settings.manage'),'current' => request()->routeIs('notification-settings.*'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                        Pengaturan Notifikasi
                    <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('school_documents.view')): ?>
                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['dataSchoolMenu' => true,'class' => \Illuminate\Support\Arr::toCssClasses([
                                'opacity-60 cursor-not-allowed' => ! $hasActiveSchool,
                            ]),'icon' => 'document-text','href' => route('settings.school-documents'),'current' => request()->routeIs('settings.school-documents'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Dokumen Sekolah
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['dataSchoolMenu', 'class', 'href', 'current', 'wire:navigate'], ['dataSchoolMenu' => 'data-school-menu'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_score_settings.view')): ?>
                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['dataSchoolMenu' => true,'class' => \Illuminate\Support\Arr::toCssClasses([
                                'opacity-60 cursor-not-allowed' => ! $hasActiveSchool,
                            ]),'icon' => 'adjustments-horizontal','href' => route('settings.attendance-scoring'),'current' => request()->routeIs('settings.attendance-scoring'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Bobot Kehadiran
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['dataSchoolMenu', 'class', 'href', 'current', 'wire:navigate'], ['dataSchoolMenu' => 'data-school-menu'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assessments.view')): ?>
                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['dataSchoolMenu' => true,'class' => \Illuminate\Support\Arr::toCssClasses([
                                'opacity-60 cursor-not-allowed' => ! $hasActiveSchool,
                            ]),'icon' => 'clipboard-document-check','href' => route('assessments.settings'),'current' => request()->routeIs('assessments.settings'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Pengaturan Penilaian
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['dataSchoolMenu', 'class', 'href', 'current', 'wire:navigate'], ['dataSchoolMenu' => 'data-school-menu'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('letters.settings')): ?>
                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['dataSchoolMenu' => true,'class' => \Illuminate\Support\Arr::toCssClasses([
                                'opacity-60 cursor-not-allowed' => ! $hasActiveSchool,
                            ]),'icon' => 'cog-6-tooth','href' => route('letters.settings'),'current' => request()->routeIs('letters.settings'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Pengaturan Persuratan
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['dataSchoolMenu', 'class', 'href', 'current', 'wire:navigate'], ['dataSchoolMenu' => 'data-school-menu'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                    <?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($currentUser?->isSuperAdmin()): ?>
                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'chat-bubble-left-ellipsis','href' => route('settings.messaging'),'current' => request()->routeIs('settings.messaging'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Integrasi Pesan
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('landing.manage')): ?>
                        <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['icon' => 'wrench-screwdriver','href' => route('settings.landing-content'),'current' => request()->routeIs('settings.landing-content'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                            Landing Page
                        <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                    <?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($contentSchool): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('school-landing.manage', $contentSchool)): ?>
                            <?php if (!function_exists('_9a2efb6e4050d7485eb368a8c72b7c41')) { $__blaze->compile('D:\laragon\www\SIMOPRAM-1\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'); require $__blaze->compiledPath.'/9a2efb6e4050d7485eb368a8c72b7c41.php'; } ?>
<?php if (isset($__slots9a2efb6e4050d7485eb368a8c72b7c41)) { $__slotsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__slots9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php if (isset($__attrs9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrsStack9a2efb6e4050d7485eb368a8c72b7c41[] = $__attrs9a2efb6e4050d7485eb368a8c72b7c41; } ?>
<?php $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = ['dataSchoolMenu' => true,'class' => \Illuminate\Support\Arr::toCssClasses([
                                    'opacity-60 cursor-not-allowed' => ! $hasActiveSchool,
                                ]),'icon' => 'wrench-screwdriver','href' => route('settings.tenant-content', $contentSchool),'current' => request()->routeIs('settings.tenant-content'),'wire:navigate' => true]; ?>
<?php $__slots9a2efb6e4050d7485eb368a8c72b7c41 = []; ?>
<?php $__blaze->pushData($__attrs9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php ob_start(); ?>
                                Halaman Sekolah
                            <?php $__slots9a2efb6e4050d7485eb368a8c72b7c41['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9a2efb6e4050d7485eb368a8c72b7c41); ?>
<?php _9a2efb6e4050d7485eb368a8c72b7c41($__blaze, $__attrs9a2efb6e4050d7485eb368a8c72b7c41, $__slots9a2efb6e4050d7485eb368a8c72b7c41, ['dataSchoolMenu', 'class', 'href', 'current', 'wire:navigate'], ['dataSchoolMenu' => 'data-school-menu'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__slots9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__slotsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php if (! empty($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41)) { $__attrs9a2efb6e4050d7485eb368a8c72b7c41 = array_pop($__attrsStack9a2efb6e4050d7485eb368a8c72b7c41); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php $__slotse5289dcad7f1dc2d6a8251214164a93d['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse5289dcad7f1dc2d6a8251214164a93d); ?>
<?php _e5289dcad7f1dc2d6a8251214164a93d($__blaze, $__attrse5289dcad7f1dc2d6a8251214164a93d, $__slotse5289dcad7f1dc2d6a8251214164a93d, ['expandable', 'expanded'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__slotse5289dcad7f1dc2d6a8251214164a93d = array_pop($__slotsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php if (! empty($__attrsStacke5289dcad7f1dc2d6a8251214164a93d)) { $__attrse5289dcad7f1dc2d6a8251214164a93d = array_pop($__attrsStacke5289dcad7f1dc2d6a8251214164a93d); } ?>
<?php $__blaze->popData(); ?>
            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        
        <?php ob_start(); ?><div class="flex-1" data-flux-spacer></div>
<?php echo ltrim(ob_get_clean()); ?>

        

        <?php if (isset($component)) { $__componentOriginalca54afb14f8d43d7f1acc5dbe6164a0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca54afb14f8d43d7f1acc5dbe6164a0a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desktop-user-menu','data' => ['class' => 'hidden lg:block','name' => auth()->user()->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desktop-user-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden lg:block','name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(auth()->user()->name)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca54afb14f8d43d7f1acc5dbe6164a0a)): ?>
<?php $attributes = $__attributesOriginalca54afb14f8d43d7f1acc5dbe6164a0a; ?>
<?php unset($__attributesOriginalca54afb14f8d43d7f1acc5dbe6164a0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca54afb14f8d43d7f1acc5dbe6164a0a)): ?>
<?php $component = $__componentOriginalca54afb14f8d43d7f1acc5dbe6164a0a; ?>
<?php unset($__componentOriginalca54afb14f8d43d7f1acc5dbe6164a0a); ?>
<?php endif; ?>

    <?php echo trim(ob_get_clean()); ?>

</ui-sidebar>
<?php echo ltrim(ob_get_clean()); ?>

    

    <?php ob_start(); ?><header class="[grid-area:header] z-10 min-h-14 flex items-center px-6 lg:px-8 sticky top-0 z-20 border-b border-zinc-200 bg-[#f7f5ee] py-3 shadow-sm dark:border-zinc-800 dark:bg-zinc-950" data-flux-header>
            <?php ob_start(); ?>
        <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 w-10 inline-flex -ms-2.5 bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white      shrink-0 lg:hidden" data-flux-button="data-flux-button" x-data="" x-on:click="$dispatch('flux-sidebar-toggle')" aria-label="Toggle sidebar" data-flux-sidebar-toggle="data-flux-sidebar-toggle">
        <svg class="shrink-0 [:where(&amp;)]:size-5" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M2 6.75A.75.75 0 0 1 2.75 6h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 6.75Zm0 6.5a.75.75 0 0 1 .75-.75h14.5a.75.75 0 0 1 0 1.5H2.75a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd"/>
</svg>
    </button>
<?php echo ltrim(ob_get_clean()); ?>

        <?php ob_start(); ?><div class="flex-1" data-flux-spacer></div>
<?php echo ltrim(ob_get_clean()); ?>

        <?php if (isset($component)) { $__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d = $attributes; } ?>
<?php $component = App\View\Components\AreaNavigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('area-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AreaNavigation::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d)): ?>
<?php $attributes = $__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d; ?>
<?php unset($__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d)): ?>
<?php $component = $__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d; ?>
<?php unset($__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d); ?>
<?php endif; ?>
    <?php echo trim(ob_get_clean()); ?>

    </header>
<?php echo ltrim(ob_get_clean()); ?>

    

    <?php echo e($slot); ?>


    

    <?php app("livewire")->forceAssetInjection(); ?><div x-persist="<?php echo e('toast'); ?>">
        <?php ob_start(); ?><ui-toast-group x-data x-on:toast-show.document="$el.showToast($event.detail)" popover="manual" position="bottom end"  wire:ignore>
    <?php ob_start(); ?>
            <?php ob_start(); ?><ui-toast x-data x-on:toast-show.document="! $el.closest('ui-toast-group') && $el.showToast($event.detail)" popover="manual" position="bottom end" wire:ignore>
    <template>
        <div class="max-w-sm in-[ui-toast-group]:max-w-auto in-[ui-toast-group]:w-xs sm:in-[ui-toast-group]:w-sm" data-variant="" data-flux-toast-dialog>
            <div class="p-2 flex rounded-xl shadow-lg bg-white border border-zinc-200 border-b-zinc-300/80 dark:bg-zinc-700 dark:border-zinc-600">
                <div class="flex-1 flex items-start gap-4 overflow-hidden">
                    <div class="flex-1 py-1.5 ps-2.5 flex gap-2">
                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=success]_&]:block shrink-0 mt-0.5 size-4 text-lime-600 dark:text-lime-400">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14Zm3.844-8.791a.75.75 0 0 0-1.188-.918l-3.7 4.79-1.649-1.833a.75.75 0 1 0-1.114 1.004l2.25 2.5a.75.75 0 0 0 1.15-.043l4.25-5.5Z" clip-rule="evenodd" />
                        </svg>

                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=warning]_&]:block shrink-0 mt-0.5 size-4 text-amber-500 dark:text-amber-400">
                            <path fill-rule="evenodd" d="M6.701 2.25c.577-1 2.02-1 2.598 0l5.196 9a1.5 1.5 0 0 1-1.299 2.25H2.804a1.5 1.5 0 0 1-1.3-2.25l5.197-9ZM8 4a.75.75 0 0 1 .75.75v3a.75.75 0 1 1-1.5 0v-3A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z" clip-rule="evenodd" />
                        </svg>

                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=info]_&]:block shrink-0 mt-0.5 size-4 text-cyan-500 dark:text-cyan-400">
                            <path fill-rule="evenodd" d="M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0ZM9 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0ZM6.75 8a.75.75 0 0 0 0 1.5h.75v1.75a.75.75 0 0 0 1.5 0v-2.5A.75.75 0 0 0 8.25 8h-1.5Z" clip-rule="evenodd" />
                        </svg>

                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=danger]_&]:block shrink-0 mt-0.5 size-4 text-rose-500 dark:text-rose-400">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14ZM8 4a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-1.5 0v-3A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z" clip-rule="evenodd" />
                        </svg>

                        <div>
                            
                            <div class="font-medium text-sm text-zinc-800 dark:text-white [&:not(:empty)+div]:font-normal [&:not(:empty)+div]:text-zinc-500 [&:not(:empty)+div]:dark:text-zinc-300 [&:not(:empty)]:pb-2"><slot name="heading"></slot></div>

                            
                            <div class="font-medium text-sm text-zinc-800 dark:text-white"><slot name="text"></slot></div>

                            
                            <template name="link">
                                <a class="block mt-2 font-medium text-sm text-[var(--color-accent-content)] decoration-[color-mix(in_oklab,var(--color-accent-content),transparent_80%)] underline underline-offset-[6px] hover:decoration-current"><slot name="text"></slot></a>
                            </template>
                        </div>
                    </div>

                    
                    <ui-close class="flex items-center">
                        <button type="button" class="inline-flex items-center font-medium justify-center gap-2 truncate disabled:opacity-50 dark:disabled:opacity-75 disabled:cursor-default h-8 text-sm rounded-md w-8 bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-400 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white" as="button">
                            <div>
                                <svg class="[:where(&)]:size-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" data-slot="icon">
                                    <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z"></path>
                                </svg>
                            </div>
                        </button>
                    </ui-close>
                </div>
            </div>
        </div>
    </template>
</ui-toast>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

</ui-toast-group>
<?php echo ltrim(ob_get_clean()); ?>
    </div>

    

    <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>


</body>

</html>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/components/sidebar.blade.php ENDPATH**/ ?>