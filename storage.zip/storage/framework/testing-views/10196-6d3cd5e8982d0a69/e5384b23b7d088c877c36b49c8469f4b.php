<div class="space-y-6">

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mode === 'global'): ?>

        <?php echo $__env->make(
            'livewire.dashboard.partials.global'
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php elseif($mode === 'school'): ?>

        <?php echo $__env->make(
            'livewire.dashboard.partials.school'
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php else: ?>

        <?php echo $__env->make(
            'livewire.dashboard.partials.none'
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</div><?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/livewire/dashboard/index.blade.php ENDPATH**/ ?>