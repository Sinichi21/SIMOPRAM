

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'logo',
    'theme' => 'auto',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'logo',
    'theme' => 'auto',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>




<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($variant === 'icon'): ?>

    <img
        src="<?php echo e(asset('brand/logo-icon.svg')); ?>"
        alt="<?php echo e(config('app.name', 'SIMPRAM')); ?>"
        <?php echo e($attributes); ?>

    >




<?php elseif($theme === 'light'): ?>

    <img
        src="<?php echo e(asset('brand/logo.svg')); ?>"
        alt="<?php echo e(config('app.name', 'SIMPRAM')); ?>"
        <?php echo e($attributes); ?>

    >




<?php elseif($theme === 'dark'): ?>

    <img
        src="<?php echo e(asset('brand/logo-dark.svg')); ?>"
        alt="<?php echo e(config('app.name', 'SIMPRAM')); ?>"
        <?php echo e($attributes); ?>

    >




<?php else: ?>

    <span <?php echo e($attributes->class('inline-flex items-center')); ?>>
        
        <img
            src="<?php echo e(asset('brand/logo.svg')); ?>"
            alt="<?php echo e(config('app.name', 'SIMPRAM')); ?>"
            class="h-full w-auto object-contain dark:hidden"
        >

        
        <img
            src="<?php echo e(asset('brand/logo-dark.svg')); ?>"
            alt="<?php echo e(config('app.name', 'SIMPRAM')); ?>"
            class="hidden h-full w-auto object-contain dark:block"
        >
    </span>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>