

<div
    class="app-page-heading flex flex-col gap-4
           lg:flex-row
           lg:items-start
           lg:justify-between"
>
    <div>
        <div
            class="mb-2 inline-flex
                   rounded-full
                   bg-zinc-100
                   px-3 py-1
                   text-xs font-medium
                   dark:bg-zinc-800"
        >
            SEKOLAH AKTIF
        </div>

        <h1 class="text-2xl font-semibold">
            Dashboard Gugus Depan
        </h1>

        <p class="mt-1 text-sm text-zinc-500">
            <?php echo e($school->name); ?>

        </p>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($dashboard['academicYear']): ?>
            <p class="mt-1 text-sm text-zinc-500">
                Tahun Ajaran
                <?php echo e($dashboard['academicYear']->name); ?>


                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($dashboard['semester']): ?>
                    · <?php echo e($dashboard['semester']->name); ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </p>
        <?php else: ?>
            <p class="mt-1 text-sm text-amber-600">
                Belum ada tahun ajaran aktif.
            </p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>


    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->isSuperAdmin()): ?>
        <form
            method="POST"
            action="<?php echo e(route('school.switch')); ?>"
        >
            <?php echo csrf_field(); ?>

            <input
                type="hidden"
                name="school_id"
                value="global"
            >

            <button
                type="submit"
                class="rounded-lg border
                       border-zinc-300
                       px-4 py-2
                       text-sm font-medium
                       hover:bg-zinc-50
                       dark:border-zinc-700
                       dark:hover:bg-zinc-800"
            >
                🌐 Kembali ke Dashboard Global
            </button>
        </form>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>




<div
    class="grid gap-4
           sm:grid-cols-2
           xl:grid-cols-4"
>
    <div
        class="rounded-xl border
               border-zinc-200
               bg-white p-5
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >
        <div class="text-sm text-zinc-500">
            Siswa Aktif
        </div>

        <div class="mt-2 text-3xl font-semibold">
            <?php echo e(number_format(
                $dashboard['studentCount']
            )); ?>

        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('students.view')): ?>
            <a
                href="<?php echo e(route('students.index')); ?>"
                wire:navigate
                class="mt-3 inline-block
                       text-xs font-medium
                       text-zinc-600 underline
                       dark:text-zinc-300"
            >
                Lihat siswa
            </a>
        <?php endif; ?>
    </div>


    <div
        class="rounded-xl border
               border-zinc-200
               bg-white p-5
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >
        <div class="text-sm text-zinc-500">
            Pembina Aktif
        </div>

        <div class="mt-2 text-3xl font-semibold">
            <?php echo e(number_format(
                $dashboard['coachCount']
            )); ?>

        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coaches.view')): ?>
            <a
                href="<?php echo e(route('coaches.index')); ?>"
                wire:navigate
                class="mt-3 inline-block
                       text-xs font-medium
                       text-zinc-600 underline
                       dark:text-zinc-300"
            >
                Lihat pembina
            </a>
        <?php endif; ?>
    </div>


    <div
        class="rounded-xl border
               border-zinc-200
               bg-white p-5
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >
        <div class="text-sm text-zinc-500">
            Regu / Barung
        </div>

        <div class="mt-2 text-3xl font-semibold">
            <?php echo e(number_format(
                $dashboard['scoutUnitCount']
            )); ?>

        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('scout_units.view')): ?>
            <a
                href="<?php echo e(route('scout-units.index')); ?>"
                wire:navigate
                class="mt-3 inline-block
                       text-xs font-medium
                       text-zinc-600 underline
                       dark:text-zinc-300"
            >
                Lihat Regu / Barung
            </a>
        <?php endif; ?>
    </div>


    <div
        class="rounded-xl border
               border-zinc-200
               bg-white p-5
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >
        <div class="text-sm text-zinc-500">
            Kegiatan Periode Ini
        </div>

        <div class="mt-2 text-3xl font-semibold">
            <?php echo e(number_format(
                $dashboard['activityCount']
            )); ?>

        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activities.view')): ?>
            <a
                href="<?php echo e(route('activities.index')); ?>"
                wire:navigate
                class="mt-3 inline-block
                       text-xs font-medium
                       text-zinc-600 underline
                       dark:text-zinc-300"
            >
                Lihat kegiatan
            </a>
        <?php endif; ?>
    </div>
</div>




<section
    class="rounded-xl border
           border-zinc-200
           bg-white p-6
           shadow-sm
           dark:border-zinc-800
           dark:bg-zinc-900"
>
    <div
        class="flex flex-col gap-3
               md:flex-row
               md:items-center
               md:justify-between"
    >
        <div>
            <h2 class="text-lg font-semibold">
                Kehadiran
            </h2>

            <p class="mt-1 text-sm text-zinc-500">
                Ringkasan seluruh sesi absensi
                pada periode aktif.
            </p>
        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.attendance.view')): ?>
            <a
                href="<?php echo e(route(
                    'reports.attendance'
                )); ?>"
                wire:navigate
                class="text-sm font-medium underline"
            >
                Lihat Rekap Absensi
            </a>
        <?php endif; ?>
    </div>


    <div
        class="mt-6 grid gap-3
               sm:grid-cols-2
               md:grid-cols-4
               xl:grid-cols-7"
    >
        <?php
            $attendanceCards = [
                'Hadir' => $dashboard['present'],
                'Terlambat' => $dashboard['late'],
                'Sakit' => $dashboard['sick'],
                'Izin' => $dashboard['excused'],
                'Alpa' => $dashboard['absent'],
                'Belum Dicatat' => $dashboard['unrecorded'],
            ];
        ?>


        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $attendanceCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div
                class="rounded-lg border
                       border-zinc-200
                       p-4
                       dark:border-zinc-700"
            >
                <div class="text-2xl font-semibold">
                    <?php echo e(number_format($value)); ?>

                </div>

                <div
                    class="mt-1 text-xs
                           text-zinc-500"
                >
                    <?php echo e($label); ?>

                </div>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>


        <div
            class="rounded-lg border
                   border-zinc-200
                   p-4
                   dark:border-zinc-700"
        >
            <div class="text-2xl font-semibold">
                <?php echo e(number_format(
                    $dashboard[
                        'presencePercentage'
                    ],
                    2
                )); ?>%
            </div>

            <div
                class="mt-1 text-xs
                       text-zinc-500"
            >
                Kehadiran Fisik
            </div>
        </div>
    </div>


    <div class="mt-5">
        <div
            class="mb-2 flex
                   justify-between
                   text-xs
                   text-zinc-500"
        >
            <span>
                Persentase Kehadiran
            </span>

            <span>
                <?php echo e(number_format(
                    $dashboard[
                        'presencePercentage'
                    ],
                    2
                )); ?>%
            </span>
        </div>


        <div
            class="h-2 overflow-hidden
                   rounded-full
                   bg-zinc-100
                   dark:bg-zinc-800"
        >
            <div
                class="h-full rounded-full
                       bg-zinc-900
                       dark:bg-white"
                style="width: <?php echo e(min(
                    100,
                    $dashboard[
                        'presencePercentage'
                    ]
                )); ?>%"
            ></div>
        </div>
    </div>
</section>




<div class="grid gap-4 lg:grid-cols-2">

    

    <section
        class="rounded-xl border
               border-zinc-200
               bg-white p-6
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >
        <div
            class="flex items-center
                   justify-between"
        >
            <div>
                <h2 class="text-lg font-semibold">
                    Jurnal Kegiatan
                </h2>

                <p
                    class="mt-1 text-sm
                           text-zinc-500"
                >
                    Administrasi jurnal
                    kegiatan periode aktif.
                </p>
            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('journals.view')): ?>
                <a
                    href="<?php echo e(route(
                        'journals.index'
                    )); ?>"
                    wire:navigate
                    class="text-sm underline"
                >
                    Lihat Semua
                </a>
            <?php endif; ?>
        </div>


        <div
            class="mt-6
                   grid grid-cols-2
                   gap-4"
        >
            <div>
                <div class="text-3xl font-semibold">
                    <?php echo e(number_format(
                        $dashboard[
                            'journalCount'
                        ]
                    )); ?>

                </div>

                <div
                    class="mt-1 text-sm
                           text-zinc-500"
                >
                    Total jurnal
                </div>
            </div>


            <div>
                <div class="text-3xl font-semibold">
                    <?php echo e(number_format(
                        $dashboard[
                            'publishedJournalCount'
                        ]
                    )); ?>

                </div>

                <div
                    class="mt-1 text-sm
                           text-zinc-500"
                >
                    Dipublikasikan
                </div>
            </div>
        </div>


        <?php
            $journalPercentage =
                $dashboard['journalCount'] > 0
                    ? round(
                        (
                            $dashboard[
                                'publishedJournalCount'
                            ]
                            /
                            $dashboard[
                                'journalCount'
                            ]
                        ) * 100,
                        2
                    )
                    : 0;
        ?>


        <div class="mt-5">
            <div
                class="mb-2 flex
                       justify-between
                       text-xs
                       text-zinc-500"
            >
                <span>
                    Jurnal dipublikasikan
                </span>

                <span>
                    <?php echo e(number_format(
                        $journalPercentage,
                        2
                    )); ?>%
                </span>
            </div>

            <div
                class="h-2 overflow-hidden
                       rounded-full
                       bg-zinc-100
                       dark:bg-zinc-800"
            >
                <div
                    class="h-full rounded-full
                           bg-zinc-900
                           dark:bg-white"
                    style="width: <?php echo e(min(
                        100,
                        $journalPercentage
                    )); ?>%"
                ></div>
            </div>
        </div>
    </section>


    

    <section
        class="rounded-xl border
               border-zinc-200
               bg-white p-6
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >
        <div
            class="flex items-center
                   justify-between"
        >
            <div>
                <h2 class="text-lg font-semibold">
                    Penilaian
                </h2>

                <p
                    class="mt-1 text-sm
                           text-zinc-500"
                >
                    Ringkasan hasil penilaian
                    Pramuka.
                </p>
            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.grades.view')): ?>
                <a
                    href="<?php echo e(route(
                        'reports.grades'
                    )); ?>"
                    wire:navigate
                    class="text-sm underline"
                >
                    Rekap Nilai
                </a>
            <?php endif; ?>
        </div>


        <div
            class="mt-6
                   grid grid-cols-2
                   gap-4"
        >
            <div>
                <div class="text-3xl font-semibold">
                    <?php echo e(number_format(
                        $dashboard[
                            'averageFinalGrade'
                        ],
                        2
                    )); ?>

                </div>

                <div
                    class="mt-1 text-sm
                           text-zinc-500"
                >
                    Rata-rata nilai
                </div>
            </div>


            <div>
                <div class="text-3xl font-semibold">
                    <?php echo e(number_format(
                        $dashboard[
                            'gradedStudentCount'
                        ]
                    )); ?>

                </div>

                <div
                    class="mt-1 text-sm
                           text-zinc-500"
                >
                    Siswa telah dinilai
                </div>
            </div>
        </div>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assessments.scores.view')): ?>
            <a
                href="<?php echo e(route(
                    'assessments.scores'
                )); ?>"
                wire:navigate
                class="mt-5 inline-block
                       text-sm font-medium
                       underline"
            >
                Kelola Penilaian
            </a>
        <?php endif; ?>
    </section>
</div>




<section
    class="rounded-xl border
           border-zinc-200
           bg-white p-6
           shadow-sm
           dark:border-zinc-800
           dark:bg-zinc-900"
>
    <div
        class="flex flex-col gap-2
               sm:flex-row
               sm:items-center
               sm:justify-between"
    >
        <div>
            <h2 class="text-lg font-semibold">
                Aktivitas 6 Bulan Terakhir
            </h2>

            <p
                class="mt-1 text-sm
                       text-zinc-500"
            >
                Jumlah agenda kegiatan setiap bulan.
            </p>
        </div>

        <div
            class="rounded-lg
                   bg-zinc-100
                   px-3 py-2
                   text-sm
                   dark:bg-zinc-800"
        >
            Total:
            <strong>
                <?php echo e(number_format(
                    $dashboard[
                        'activityByMonth'
                    ]->sum('total')
                )); ?>

            </strong>
        </div>
    </div>


    <?php
        $maxActivity =
            max(
                1,
                $dashboard[
                    'activityByMonth'
                ]->max('total')
            );
    ?>


    <div class="mt-6 space-y-4">

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $dashboard['activityByMonth']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php
                $width =
                    (
                        $month['total']
                        /
                        $maxActivity
                    )
                    * 100;
            ?>


            <div>
                <div
                    class="mb-1 flex
                           justify-between
                           text-sm"
                >
                    <span>
                        <?php echo e($month['label']); ?>

                    </span>

                    <span class="font-medium">
                        <?php echo e($month['total']); ?>

                    </span>
                </div>


                <div
                    class="h-2 overflow-hidden
                           rounded-full
                           bg-zinc-100
                           dark:bg-zinc-800"
                >
                    <div
                        class="h-full rounded-full
                               bg-zinc-900
                               dark:bg-white"
                        style="width: <?php echo e($width); ?>%"
                    ></div>
                </div>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

    </div>
</section>




<div class="grid gap-4 xl:grid-cols-2">

    

    <section
        class="rounded-xl border
               border-zinc-200
               bg-white p-6
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >
        <div
            class="flex items-center
                   justify-between"
        >
            <div>
                <h2 class="text-lg font-semibold">
                    Agenda Mendatang
                </h2>

                <p
                    class="mt-1 text-sm
                           text-zinc-500"
                >
                    Maksimal 5 agenda terdekat.
                </p>
            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activities.view')): ?>
                <a
                    href="<?php echo e(route(
                        'activities.index'
                    )); ?>"
                    wire:navigate
                    class="text-sm underline"
                >
                    Lihat Semua
                </a>
            <?php endif; ?>
        </div>


        <div class="mt-5 space-y-3">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $dashboard[
                    'upcomingActivities'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div
                    class="rounded-lg border
                           border-zinc-200
                           p-4
                           dark:border-zinc-700"
                >
                    <div
                        class="flex flex-col
                               gap-2
                               sm:flex-row
                               sm:items-start
                               sm:justify-between"
                    >
                        <div>
                            <div class="font-medium">
                                <?php echo e($activity->title); ?>

                            </div>

                            <div
                                class="mt-1 text-sm
                                       text-zinc-500"
                            >
                                <?php echo e($activity
                                    ->start_at
                                    ->format(
                                        'd-m-Y H:i'
                                    )); ?>

                            </div>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activity->location): ?>
                                <div
                                    class="mt-1
                                           text-xs
                                           text-zinc-500"
                                >
                                    <?php echo e($activity->location); ?>

                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>


                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                            $activity->status
                            === 'published'
                        ): ?>
                            <span
                                class="rounded-full
                                       bg-green-100
                                       px-2 py-1
                                       text-xs
                                       font-medium
                                       text-green-700"
                            >
                                Published
                            </span>
                        <?php elseif(
                            $activity->status
                            === 'draft'
                        ): ?>
                            <span
                                class="rounded-full
                                       bg-amber-100
                                       px-2 py-1
                                       text-xs
                                       font-medium
                                       text-amber-700"
                            >
                                Draft
                            </span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>


                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activity->coaches->isNotEmpty()): ?>
                        <div
                            class="mt-3
                                   text-xs
                                   text-zinc-500"
                        >
                            Pembina:
                            <?php echo e($activity
                                ->coaches
                                ->pluck('name')
                                ->join(', ')); ?>

                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div
                    class="rounded-lg
                           border border-dashed
                           border-zinc-300
                           py-10
                           text-center
                           text-sm
                           text-zinc-500
                           dark:border-zinc-700"
                >
                    Belum ada agenda mendatang.
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>
    </section>


    

    <section
        class="rounded-xl border
               border-zinc-200
               bg-white p-6
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >
        <div
            class="flex items-center
                   justify-between"
        >
            <div>
                <h2 class="text-lg font-semibold">
                    Pengumuman Terbaru
                </h2>

                <p
                    class="mt-1 text-sm
                           text-zinc-500"
                >
                    Informasi terbaru di sekolah.
                </p>
            </div>


            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                Route::has(
                    'announcements.my'
                )
            ): ?>
                <a
                    href="<?php echo e(route(
                        'announcements.my'
                    )); ?>"
                    wire:navigate
                    class="text-sm underline"
                >
                    Lihat Semua
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>


        <div class="mt-5 space-y-3">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $dashboard[
                    'latestAnnouncements'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <article
                    class="rounded-lg border
                           border-zinc-200
                           p-4
                           dark:border-zinc-700"
                >
                    <div
                        class="flex items-start
                               justify-between
                               gap-3"
                    >
                        <div class="font-medium">
                            <?php echo e($announcement->title); ?>

                        </div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                            $announcement->is_public
                        ): ?>
                            <span
                                class="rounded-full
                                       bg-zinc-100
                                       px-2 py-1
                                       text-xs
                                       dark:bg-zinc-800"
                            >
                                Publik
                            </span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>


                    <div
                        class="mt-1
                               text-xs
                               text-zinc-500"
                    >
                        <?php echo e($announcement
                            ->published_at
                            ?->format(
                                'd-m-Y H:i'
                            )); ?>

                    </div>


                    <p
                        class="mt-2 text-sm
                               leading-6
                               text-zinc-600
                               dark:text-zinc-300"
                    >
                        <?php echo e(\Illuminate\Support\Str::limit(
                            $announcement->body,
                            150
                        )); ?>

                    </p>
                </article>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div
                    class="rounded-lg
                           border border-dashed
                           border-zinc-300
                           py-10
                           text-center
                           text-sm
                           text-zinc-500
                           dark:border-zinc-700"
                >
                    Belum ada pengumuman terbaru.
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>
    </section>

</div>




<section
    class="rounded-xl border
           border-zinc-200
           bg-white p-6
           shadow-sm
           dark:border-zinc-800
           dark:bg-zinc-900"
>
    <h2 class="text-lg font-semibold">
        Akses Cepat
    </h2>

    <p
        class="mt-1 text-sm
               text-zinc-500"
    >
        Buka modul operasional yang paling
        sering digunakan.
    </p>


    <div
        class="mt-5 grid gap-3
               sm:grid-cols-2
               lg:grid-cols-4"
    >
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activities.view')): ?>
            <a
                href="<?php echo e(route(
                    'activities.index'
                )); ?>"
                wire:navigate
                class="rounded-lg border
                       border-zinc-200
                       p-4
                       transition
                       hover:bg-zinc-50
                       dark:border-zinc-700
                       dark:hover:bg-zinc-800"
            >
                <div class="font-medium">
                    Agenda / Kegiatan
                </div>

                <div
                    class="mt-1 text-xs
                           text-zinc-500"
                >
                    Kelola kegiatan Pramuka
                </div>
            </a>
        <?php endif; ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('journals.view')): ?>
            <a
                href="<?php echo e(route(
                    'journals.index'
                )); ?>"
                wire:navigate
                class="rounded-lg border
                       border-zinc-200
                       p-4
                       transition
                       hover:bg-zinc-50
                       dark:border-zinc-700
                       dark:hover:bg-zinc-800"
            >
                <div class="font-medium">
                    Jurnal
                </div>

                <div
                    class="mt-1 text-xs
                           text-zinc-500"
                >
                    Dokumentasi kegiatan
                </div>
            </a>
        <?php endif; ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assessments.scores.view')): ?>
            <a
                href="<?php echo e(route(
                    'assessments.scores'
                )); ?>"
                wire:navigate
                class="rounded-lg border
                       border-zinc-200
                       p-4
                       transition
                       hover:bg-zinc-50
                       dark:border-zinc-700
                       dark:hover:bg-zinc-800"
            >
                <div class="font-medium">
                    Input Nilai
                </div>

                <div
                    class="mt-1 text-xs
                           text-zinc-500"
                >
                    Penilaian siswa
                </div>
            </a>
        <?php endif; ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.attendance.view')): ?>
            <a
                href="<?php echo e(route(
                    'reports.attendance'
                )); ?>"
                wire:navigate
                class="rounded-lg border
                       border-zinc-200
                       p-4
                       transition
                       hover:bg-zinc-50
                       dark:border-zinc-700
                       dark:hover:bg-zinc-800"
            >
                <div class="font-medium">
                    Rekap Absensi
                </div>

                <div
                    class="mt-1 text-xs
                           text-zinc-500"
                >
                    Monitoring kehadiran
                </div>
            </a>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/livewire/dashboard/partials/school.blade.php ENDPATH**/ ?>