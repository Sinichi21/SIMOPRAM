<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'school' => null,

    /*
    |--------------------------------------------------------------------------
    | Logo configuration
    |--------------------------------------------------------------------------
    |
    | logoVariant:
    | - logo = logo lengkap
    | - icon = icon saja
    |
    | logoTheme:
    | - auto  = logo.svg untuk light, logo-dark.svg untuk dark
    | - light = selalu logo.svg
    | - dark  = selalu logo-dark.svg
    |
    */

    'logoVariant' => 'logo',
    'logoTheme' => 'auto',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'school' => null,

    /*
    |--------------------------------------------------------------------------
    | Logo configuration
    |--------------------------------------------------------------------------
    |
    | logoVariant:
    | - logo = logo lengkap
    | - icon = icon saja
    |
    | logoTheme:
    | - auto  = logo.svg untuk light, logo-dark.svg untuk dark
    | - light = selalu logo.svg
    | - dark  = selalu logo-dark.svg
    |
    */

    'logoVariant' => 'logo',
    'logoTheme' => 'auto',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<header
    class="relative z-40 border-b border-zinc-200 bg-white text-zinc-900
           dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
>
    
    <div
        class="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4
               px-5 py-3 lg:px-8"
    >
        <a
            href="<?php echo e($school ? route('schools.landing', $school) : route('home')); ?>"
            class="flex min-w-0 items-center gap-3"
        >
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school): ?>

                
                
                

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school->logo): ?>

                    <img
                        src="<?php echo e(Storage::disk('public')->url($school->logo)); ?>"
                        alt="Logo <?php echo e($school->name); ?>"
                        class="size-14 shrink-0 rounded-xl bg-white object-contain p-1"
                    >

                <?php else: ?>

                    
                    <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['variant' => 'icon','theme' => 'auto','class' => 'size-14 shrink-0 object-contain']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'icon','theme' => 'auto','class' => 'size-14 shrink-0 object-contain']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <span class="min-w-0">
                    <strong
                        class="block max-w-xs truncate text-sm font-bold tracking-tight
                               sm:max-w-md"
                    >
                        <?php echo e($school->name); ?>

                    </strong>

                    <span
                        class="text-[10px] font-bold tracking-widest
                               text-emerald-700 dark:text-emerald-300"
                    >
                        PRAMUKA DIGITAL
                    </span>
                </span>

            <?php else: ?>

                
                
                

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($logoVariant === 'icon'): ?>

                    <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['variant' => 'icon','theme' => $logoTheme,'class' => 'size-14 shrink-0 object-contain sm:size-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'icon','theme' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($logoTheme),'class' => 'size-14 shrink-0 object-contain sm:size-16']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>

                <?php else: ?>

                    <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['variant' => 'logo','theme' => $logoTheme,'class' => 'h-14 w-auto shrink-0 sm:h-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'logo','theme' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($logoTheme),'class' => 'h-14 w-auto shrink-0 sm:h-16']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </a>

        
        <?php if (isset($component)) { $__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d = $attributes; } ?>
<?php $component = App\View\Components\AreaNavigation::resolve(['school' => $school] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('area-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AreaNavigation::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d)): ?>
<?php $attributes = $__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d; ?>
<?php unset($__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d)): ?>
<?php $component = $__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d; ?>
<?php unset($__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d); ?>
<?php endif; ?>
    </div>


    
    
    

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school || request()->routeIs('home', 'public.*')): ?>

        <nav
            aria-label="Navigasi halaman"
            class="mx-auto flex max-w-7xl flex-wrap gap-x-6 gap-y-2
                   px-5 pb-3 text-sm font-semibold text-zinc-600
                   lg:px-8 dark:text-zinc-300"
        >

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school): ?>

                <a
                    href="<?php echo e(route('schools.landing', $school)); ?>#profil"
                    class="transition hover:text-emerald-700
                           dark:hover:text-emerald-300"
                >
                    Profil sekolah
                </a>

                <a
                    href="<?php echo e(route('schools.landing', $school)); ?>#agenda"
                    class="transition hover:text-emerald-700
                           dark:hover:text-emerald-300"
                >
                    Pengumuman & kegiatan
                </a>

                <a
                    href="<?php echo e(route('schools.landing', $school)); ?>#dokumentasi"
                    class="transition hover:text-emerald-700
                           dark:hover:text-emerald-300"
                >
                    Dokumentasi
                </a>

                <a
                    href="<?php echo e(route('schools.landing', $school)); ?>#kontak"
                    class="transition hover:text-emerald-700
                           dark:hover:text-emerald-300"
                >
                    Kontak
                </a>

            <?php else: ?>

                <a href="<?php echo e(route('home')); ?>#agenda" class="transition hover:text-emerald-700 dark:hover:text-emerald-300">Pengumuman &amp; kegiatan</a>
                <a
                    href="<?php echo e(route('home')); ?>#fitur"
                    class="transition hover:text-emerald-700
                           dark:hover:text-emerald-300"
                >
                    Fitur
                </a>

                <a
                    href="<?php echo e(route('home')); ?>#sekolah"
                    class="transition hover:text-emerald-700
                           dark:hover:text-emerald-300"
                >
                    Sekolah
                </a>

                <a
                    href="<?php echo e(route('home')); ?>#daftar-sekolah"
                    class="transition hover:text-emerald-700
                           dark:hover:text-emerald-300"
                >
                    Daftarkan sekolah
                </a>

                <a
                    href="<?php echo e(route('complaints.public')); ?>"
                    class="transition hover:text-emerald-700
                           dark:hover:text-emerald-300"
                >
                    Pengaduan
                </a>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </nav>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</header>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/components/public-header.blade.php ENDPATH**/ ?>