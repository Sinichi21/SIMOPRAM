<div class="space-y-6">

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($assessment->is_special): ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('assessments.activities.judges', ['assessment-id' => $assessment->id]);

$__keyOuter = $__key ?? null;

$__key = 'judges-'.$assessment->id;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-671460961-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    

    <div
        class="flex flex-col gap-4
               lg:flex-row
               lg:items-start
               lg:justify-between"
    >
        <div>
            <div
                class="text-sm text-zinc-500"
            >
                Penilaian Kegiatan
            </div>

            <h1
                class="mt-1 text-2xl
                       font-semibold"
            >
                <?php echo e($assessment->title); ?>

            </h1>

            <p
                class="mt-1 text-sm
                       text-zinc-500"
            >
                <?php echo e($assessment->activity?->title ?? '-'); ?>

                ·
                <?php echo e($assessment->mode === 'individual'
                    ? 'Individu'
                    : 'Regu'); ?>

            </p>
        </div>


        <div
            class="flex flex-wrap gap-2"
        >
            <a
                href="<?php echo e(route(
                    'activity-assessments.index'
                )); ?>"
                wire:navigate
                class="rounded-lg border
                       border-zinc-300
                       px-4 py-2
                       text-sm font-medium
                       dark:border-zinc-700"
            >
                Kembali
            </a>


            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                $assessment->status
                === 'published'
            ): ?>

                <a
                    href="<?php echo e(route(
                        $assessment->is_special ? 'activity-assessments.edit' : 'activity-assessments.score',
                        $assessment->id
                    )); ?>"
                    wire:navigate
                    class="rounded-lg
                           bg-zinc-900
                           px-4 py-2
                           text-sm font-medium
                           text-white
                           dark:bg-white
                           dark:text-zinc-900"
                >
                    <?php echo e($assessment->is_special ? 'Juri & Peringkat' : 'Input Nilai'); ?>

                </a>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>


    

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>

        <div
            class="rounded-lg border
                   border-green-200
                   bg-green-50
                   px-4 py-3
                   text-sm text-green-700
                   dark:border-green-900
                   dark:bg-green-950
                   dark:text-green-300"
        >
            <?php echo e(session('status')); ?>

        </div>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['form'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div
            class="rounded-lg border
                   border-red-200
                   bg-red-50
                   px-4 py-3
                   text-sm text-red-700"
        >
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['criteria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div
            class="rounded-lg border
                   border-red-200
                   bg-red-50
                   px-4 py-3
                   text-sm text-red-700"
        >
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    

    <div
        class="grid gap-4
               sm:grid-cols-2
               xl:grid-cols-4"
    >

        <div
            class="rounded-xl border
                   border-zinc-200
                   bg-white p-4
                   dark:border-zinc-800
                   dark:bg-zinc-900"
        >
            <div
                class="text-xs text-zinc-500"
            >
                Status
            </div>

            <div
                class="mt-1 font-semibold"
            >
                <?php echo e(ucfirst(
                    $assessment->status
                )); ?>

            </div>
        </div>


        <div
            class="rounded-xl border
                   border-zinc-200
                   bg-white p-4
                   dark:border-zinc-800
                   dark:bg-zinc-900"
        >
            <div
                class="text-xs text-zinc-500"
            >
                Total Bobot
            </div>

            <div
                class="mt-1 text-xl
                       font-semibold"
            >
                <?php echo e(number_format(
                    $totalWeight,
                    2
                )); ?>%
            </div>
        </div>


        <div
            class="rounded-xl border
                   border-zinc-200
                   bg-white p-4
                   dark:border-zinc-800
                   dark:bg-zinc-900"
        >
            <div
                class="text-xs text-zinc-500"
            >
                Target
            </div>

            <div
                class="mt-1 text-xl
                       font-semibold"
            >
                <?php echo e(number_format(
                    $targetCount
                )); ?>

            </div>
        </div>


        <div
            class="rounded-xl border
                   border-zinc-200
                   bg-white p-4
                   dark:border-zinc-800
                   dark:bg-zinc-900"
        >
            <div
                class="text-xs text-zinc-500"
            >
                Sudah Dinilai
            </div>

            <div
                class="mt-1 text-xl
                       font-semibold"
            >
                <?php echo e(number_format(
                    $assessedCount
                )); ?>

            </div>
        </div>

    </div>


    

    <form
        wire:submit="saveForm"
        class="rounded-xl border
               border-zinc-200
               bg-white p-6
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >

        <h2
            class="text-lg font-semibold"
        >
            Informasi Form
        </h2>


        <div
            class="mt-5 grid gap-4
                   md:grid-cols-2"
        >

            <div>
                <label
                    class="mb-1 block
                           text-sm font-medium"
                >
                    Nama Form
                </label>

                <input
                    type="text"
                    wire:model="title"
                    <?php if(
                        $assessment->status
                        !== 'draft'
                    ): echo 'disabled'; endif; ?>
                    class="w-full rounded-lg
                           border border-zinc-300
                           bg-white px-3 py-2
                           disabled:opacity-60
                           dark:border-zinc-700
                           dark:bg-zinc-950"
                >

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600">
                        <?php echo e($message); ?>

                    </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>


            <div>
                <label
                    class="mb-1 block
                           text-sm font-medium"
                >
                    <?php echo e($assessment->is_special ? 'Kegiatan khusus — tidak masuk semester' : 'Faktor Tujuan'); ?>

                </label>

                <select
                    wire:model="assessmentFactorId"
                    <?php if(
                        $assessment->is_special || $assessment->status
                        !== 'draft'
                    ): echo 'disabled'; endif; ?>
                    class="w-full rounded-lg
                           border border-zinc-300
                           bg-white px-3 py-2
                           disabled:opacity-60
                           dark:border-zinc-700
                           dark:bg-zinc-950"
                >

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $factors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                        <option
                            value="<?php echo e($factor->id); ?>"
                        >
                            <?php echo e($factor->name); ?>

                        </option>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                </select>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['assessmentFactorId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600">
                        <?php echo e($message); ?>

                    </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>


            <div>
                <label
                    class="mb-1 block
                           text-sm font-medium"
                >
                    Mode
                </label>

                <select
                    wire:model="mode"
                    <?php if(
                        $assessment->status
                        !== 'draft'
                    ): echo 'disabled'; endif; ?>
                    class="w-full rounded-lg
                           border border-zinc-300
                           bg-white px-3 py-2
                           disabled:opacity-60
                           dark:border-zinc-700
                           dark:bg-zinc-950"
                >
                    <option value="individual">
                        Individu
                    </option>

                    <option value="team">
                        Regu
                    </option>
                </select>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600">
                        <?php echo e($message); ?>

                    </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

        </div>


        <div class="mt-4">

            <label
                class="mb-1 block
                       text-sm font-medium"
            >
                Deskripsi
            </label>

            <textarea
                wire:model="description"
                rows="3"
                <?php if(
                    $assessment->status
                    !== 'draft'
                ): echo 'disabled'; endif; ?>
                class="w-full rounded-lg
                       border border-zinc-300
                       bg-white px-3 py-2
                       disabled:opacity-60
                       dark:border-zinc-700
                       dark:bg-zinc-950"
            ></textarea>

        </div>


        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
            $assessment->status
            === 'draft'
        ): ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                'activity_assessments.update'
            )): ?>

                <div
                    class="mt-5 flex
                           justify-end"
                >
                    <button
                        type="submit"
                        class="rounded-lg
                               bg-zinc-900
                               px-5 py-2.5
                               text-sm font-medium
                               text-white
                               dark:bg-white
                               dark:text-zinc-900"
                    >
                        Simpan Informasi
                    </button>
                </div>

            <?php endif; ?>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </form>


    

    <section
        class="rounded-xl border
               border-zinc-200
               bg-white p-6
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >

        <div
            class="flex flex-col gap-3
                   sm:flex-row
                   sm:items-center
                   sm:justify-between"
        >
            <div>
                <h2
                    class="text-lg font-semibold"
                >
                    Kriteria Penilaian
                </h2>

                <p
                    class="mt-1 text-sm
                           text-zinc-500"
                >
                    Total bobot kriteria wajib
                    tepat 100%.
                </p>
            </div>


            <div
                class="rounded-full
                       px-3 py-1
                       text-sm font-medium
                       <?php echo e(abs($totalWeight - 100) <= 0.01
                            ? 'bg-green-100 text-green-700'
                            : 'bg-amber-100 text-amber-700'); ?>"
            >
                <?php echo e(number_format(
                    $totalWeight,
                    2
                )); ?> / 100%
            </div>
        </div>


        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
            $assessment->status
            === 'draft'
        ): ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                'activity_assessments.update'
            )): ?>

                <form
                    wire:submit="saveCriterion"
                    class="mt-6 rounded-lg
                           border border-zinc-200
                           bg-zinc-50 p-4
                           dark:border-zinc-700
                           dark:bg-zinc-950"
                >

                    <div
                        class="grid gap-4
                               md:grid-cols-2
                               xl:grid-cols-4"
                    >

                        <div>
                            <label
                                class="mb-1 block
                                       text-sm font-medium"
                            >
                                Kriteria
                            </label>

                            <input
                                type="text"
                                wire:model="criterionName"
                                placeholder="Ketepatan simpul"
                                class="w-full rounded-lg
                                       border border-zinc-300
                                       bg-white px-3 py-2
                                       dark:border-zinc-700
                                       dark:bg-zinc-900"
                            >

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['criterionName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600">
                                    <?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>


                        <div>
                            <label
                                class="mb-1 block
                                       text-sm font-medium"
                            >
                                Nilai Maksimum
                            </label>

                            <input
                                type="number"
                                wire:model="criterionMaxScore"
                                min="0.01"
                                step="0.01"
                                class="w-full rounded-lg
                                       border border-zinc-300
                                       bg-white px-3 py-2
                                       dark:border-zinc-700
                                       dark:bg-zinc-900"
                            >
                        </div>


                        <div>
                            <label
                                class="mb-1 block
                                       text-sm font-medium"
                            >
                                Bobot
                            </label>

                            <input
                                type="number"
                                wire:model="criterionWeight"
                                min="0.01"
                                max="100"
                                step="0.01"
                                class="w-full rounded-lg
                                       border border-zinc-300
                                       bg-white px-3 py-2
                                       dark:border-zinc-700
                                       dark:bg-zinc-900"
                            >
                        </div>


                        <div
                            class="flex items-end
                                   gap-2"
                        >
                            <button
                                type="submit"
                                class="rounded-lg
                                       bg-zinc-900
                                       px-4 py-2
                                       text-sm font-medium
                                       text-white
                                       dark:bg-white
                                       dark:text-zinc-900"
                            >
                                <?php echo e($editingCriterionId
                                    ? 'Update'
                                    : 'Tambah'); ?>

                            </button>


                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                                $editingCriterionId
                            ): ?>

                                <button
                                    type="button"
                                    wire:click="cancelCriterionEdit"
                                    class="rounded-lg
                                           border
                                           border-zinc-300
                                           px-4 py-2
                                           text-sm
                                           dark:border-zinc-700"
                                >
                                    Batal
                                </button>

                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                    </div>


                    <div class="mt-4">
                        <label
                            class="mb-1 block
                                   text-sm font-medium"
                        >
                            Deskripsi Kriteria
                        </label>

                        <textarea
                            wire:model="criterionDescription"
                            rows="2"
                            class="w-full rounded-lg
                                   border border-zinc-300
                                   bg-white px-3 py-2
                                   dark:border-zinc-700
                                   dark:bg-zinc-900"
                        ></textarea>
                    </div>

                </form>

            <?php endif; ?>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


        <div
            class="mt-6 overflow-x-auto"
        >

            <table
                class="w-full text-sm"
            >
                <thead
                    class="bg-zinc-50
                           dark:bg-zinc-950"
                >
                    <tr>
                        <th class="px-4 py-3 text-left">
                            #
                        </th>

                        <th class="px-4 py-3 text-left">
                            Kriteria
                        </th>

                        <th class="px-4 py-3 text-center">
                            Maksimum
                        </th>

                        <th class="px-4 py-3 text-center">
                            Bobot
                        </th>

                        <th class="px-4 py-3 text-right">
                            Aksi
                        </th>
                    </tr>
                </thead>

                <tbody
                    class="divide-y
                           divide-zinc-200
                           dark:divide-zinc-800"
                >

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $assessment->criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                        <tr>
                            <td class="px-4 py-3">
                                <?php echo e($index + 1); ?>

                            </td>

                            <td class="px-4 py-3">
                                <div class="font-medium">
                                    <?php echo e($criterion->name); ?>

                                </div>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                                    $criterion->description
                                ): ?>
                                    <div
                                        class="mt-1 text-xs
                                               text-zinc-500"
                                    >
                                        <?php echo e($criterion->description); ?>

                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            <td
                                class="px-4 py-3
                                       text-center"
                            >
                                <?php echo e(number_format(
                                    $criterion->max_score,
                                    2
                                )); ?>

                            </td>

                            <td
                                class="px-4 py-3
                                       text-center"
                            >
                                <?php echo e(number_format(
                                    $criterion->weight,
                                    2
                                )); ?>%
                            </td>

                            <td
                                class="px-4 py-3
                                       text-right"
                            >

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                                    $assessment->status
                                    === 'draft'
                                ): ?>

                                    <button data-action-tone="edit"
                                        type="button"
                                        wire:click="editCriterion(<?php echo e($criterion->id); ?>)"
                                        class="mr-3
                                               text-sm font-medium"
                                    >
                                        Edit
                                    </button>


                                    <button data-action-tone="danger"
                                        type="button"
                                        wire:click="deleteCriterion(<?php echo e($criterion->id); ?>)"
                                        wire:confirm="Hapus kriteria ini?"
                                        class="text-sm
                                               font-medium
                                               text-red-600"
                                    >
                                        Hapus
                                    </button>

                                <?php else: ?>

                                    <span
                                        class="text-zinc-400"
                                    >
                                        Terkunci
                                    </span>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            </td>
                        </tr>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                        <tr>
                            <td
                                colspan="5"
                                class="px-4 py-8
                                       text-center
                                       text-zinc-500"
                            >
                                Belum ada kriteria.
                            </td>
                        </tr>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </tbody>
            </table>

        </div>

    </section>


    

    <section
        class="rounded-xl border
               border-zinc-200
               bg-white p-6
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >

        <h2
            class="text-lg font-semibold"
        >
            Peserta & Publikasi
        </h2>


        <p
            class="mt-1 text-sm
                   text-zinc-500"
        >
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                $assessment->mode
                === 'individual'
            ): ?>
                Sistem akan membuat satu target
                penilaian untuk setiap siswa aktif
                pada tahun ajaran kegiatan.
            <?php else: ?>
                Sistem akan membuat target per regu
                dan menyimpan snapshot anggota regu.
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </p>


        <div
            class="mt-5 flex
                   flex-wrap gap-3"
        >

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                $assessment->status
                === 'draft'
            ): ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                    'activity_assessments.update'
                )): ?>

                    <button
                        type="button"
                        wire:click="prepareTargets"
                        wire:loading.attr="disabled"
                        wire:target="prepareTargets"
                        class="rounded-lg
                               border border-zinc-300
                               px-4 py-2
                               text-sm font-medium
                               dark:border-zinc-700"
                    >
                        Siapkan Peserta
                    </button>

                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                    'activity_assessments.publish'
                )): ?>

                    <button
                        type="button"
                        wire:click="publish"
                        wire:confirm="Publikasikan form ini dan siapkan peserta penilaian?"
                        wire:loading.attr="disabled"
                        wire:target="publish"
                        <?php if(
                            abs(
                                $totalWeight - 100
                            ) > 0.01
                        ): echo 'disabled'; endif; ?>
                        class="rounded-lg
                               bg-green-700
                               px-4 py-2
                               text-sm font-medium
                               text-white
                               disabled:cursor-not-allowed
                               disabled:opacity-50"
                    >
                        Publish
                    </button>

                <?php endif; ?>

            <?php else: ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                    'activity_assessments.publish'
                )): ?>

                    <button
                        type="button"
                        wire:click="reopen"
                        wire:confirm="Kembalikan form ke Draft?"
                        class="rounded-lg
                               border border-amber-300
                               px-4 py-2
                               text-sm font-medium
                               text-amber-700"
                    >
                        Kembalikan ke Draft
                    </button>

                <?php endif; ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>

    </section>

</div>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/livewire/assessments/activities/edit.blade.php ENDPATH**/ ?>