<table><tr><th><?php echo e($schoolName); ?></th></tr><tr><td><?php echo e($periodLabel); ?></td></tr></table>
<table><tr><th>Rekap Absensi Detail - <?php echo e($activityLabel); ?></th></tr><tr><td>H: hadir; T: terlambat; S: sakit; I: izin; A: alpa; ?: belum diabsen; -: bukan peserta</td></tr></table>
<?php echo $__env->make('reports.partials.attendance-detail-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/exports/reports/attendance-detail.blade.php ENDPATH**/ ?>