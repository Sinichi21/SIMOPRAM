<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'SIMPRAM')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php echo app('flux')->fluxAppearance(); ?>

</head>

<body class="simpram-app min-h-screen bg-[#f7f5ee] text-zinc-900 antialiased dark:bg-zinc-950 dark:text-zinc-100">
    <?php if (isset($component)) { $__componentOriginal2669d93ac3865159955b6d09c48349b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2669d93ac3865159955b6d09c48349b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2669d93ac3865159955b6d09c48349b9)): ?>
<?php $attributes = $__attributesOriginal2669d93ac3865159955b6d09c48349b9; ?>
<?php unset($__attributesOriginal2669d93ac3865159955b6d09c48349b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2669d93ac3865159955b6d09c48349b9)): ?>
<?php $component = $__componentOriginal2669d93ac3865159955b6d09c48349b9; ?>
<?php unset($__componentOriginal2669d93ac3865159955b6d09c48349b9); ?>
<?php endif; ?>
    <main class="px-4 py-10 lg:py-16">
        <div class="mx-auto mb-8 max-w-3xl rounded-3xl bg-emerald-950 p-8 text-white">
            <p class="text-xs font-bold uppercase tracking-widest text-amber-300">Selamat datang di SIMPRAM</p>
            <h1 class="mt-3 text-3xl font-black tracking-tight">Satu ruang untuk bertumbuh bersama.</h1>
            <p class="mt-3 leading-7 text-emerald-100">Terhubung dengan sekolah, ikuti kegiatan, dan kembangkan potensi Pramukamu.</p>
        </div>
        <div class="mx-auto w-full max-w-3xl rounded-3xl border border-zinc-200 bg-white p-6 shadow-sm sm:p-10 dark:border-zinc-800 dark:bg-zinc-900">
            <?php echo e($slot); ?>

        </div>
    </main>

    <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

</body>
</html>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/components/layouts/auth.blade.php ENDPATH**/ ?>