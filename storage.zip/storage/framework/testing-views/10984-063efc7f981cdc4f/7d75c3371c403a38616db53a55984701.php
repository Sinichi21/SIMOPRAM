<div class="space-y-6">

    <div
        class="flex flex-col gap-4
               lg:flex-row
               lg:items-end
               lg:justify-between"
    >
        <div>
            <h1 class="text-2xl font-semibold">
                Rekap Nilai
            </h1>

            <p class="mt-1 text-sm text-zinc-500">
                Rekap hasil penilaian Pramuka
                berdasarkan periode dan kelas.
            </p>
        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.export')): ?>

            <div
                class="flex flex-wrap gap-2"
            >

                <button
                    type="button"
                    wire:click="exportCsv"
                    wire:loading.attr="disabled"
                    wire:target="exportCsv"
                    class="rounded-lg border
                        border-zinc-300
                        px-4 py-2
                        text-sm font-medium
                        hover:bg-zinc-50
                        disabled:opacity-50
                        dark:border-zinc-700
                        dark:hover:bg-zinc-800"
                >
                    <span
                        wire:loading.remove
                        wire:target="exportCsv"
                    >
                        Export CSV
                    </span>

                    <span
                        wire:loading
                        wire:target="exportCsv"
                    >
                        Memproses...
                    </span>
                </button>


                <button
                    type="button"
                    wire:click="exportExcel"
                    wire:loading.attr="disabled"
                    wire:target="exportExcel"
                    class="rounded-lg border
                        border-zinc-300
                        px-4 py-2
                        text-sm font-medium
                        hover:bg-zinc-50
                        disabled:opacity-50
                        dark:border-zinc-700
                        dark:hover:bg-zinc-800"
                >
                    <span
                        wire:loading.remove
                        wire:target="exportExcel"
                    >
                        Export Excel
                    </span>

                    <span
                        wire:loading
                        wire:target="exportExcel"
                    >
                        Memproses...
                    </span>
                </button>

                <a
                    href="<?php echo e(route(
                        'reports.grades.pdf',
                        array_filter([
                            'academic_year_id' =>
                                $academicYearId,

                            'semester_id' =>
                                $semesterId,

                            'classroom_id' =>
                                $classroomId,

                            'closure' =>
                                $closureId,
                        ])
                    )); ?>"
                    target="_blank"
                    class="inline-flex items-center
                        rounded-lg
                        bg-zinc-900
                        px-4 py-2
                        text-sm font-medium
                        text-white
                        hover:bg-zinc-800
                        dark:bg-white
                        dark:text-zinc-900"
                >
                    Export PDF
                </a>

            </div>

        <?php endif; ?>


        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['export'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

            <div
                class="mt-2 text-sm
                    text-red-600"
            >
                <?php echo e($message); ?>

            </div>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>


    <div
        class="grid gap-4 rounded-xl
               border border-zinc-200
               bg-white p-5
               md:grid-cols-4
               dark:border-zinc-800
               dark:bg-zinc-900"
    >

        <div>
            <label class="mb-1 block text-sm font-medium">
                Tahun Ajaran
            </label>

            <select
                wire:model.live="academicYearId"
                class="w-full rounded-lg
                       border border-zinc-300
                       px-3 py-2
                       dark:border-zinc-700
                       dark:bg-zinc-800"
            >
                <option value="">
                    -- Pilih --
                </option>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($year->id); ?>">
                        <?php echo e($year->name); ?>

                    </option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
        </div>


        <div>
            <label class="mb-1 block text-sm font-medium">
                Semester
            </label>

            <select
                wire:model.live="semesterId"
                class="w-full rounded-lg
                       border border-zinc-300
                       px-3 py-2
                       dark:border-zinc-700
                       dark:bg-zinc-800"
            >
                <option value="">
                    -- Pilih --
                </option>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($semester->id); ?>">
                        <?php echo e($semester->name); ?>

                    </option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
        </div>


        <div>
            <label class="mb-1 block text-sm font-medium">
                Kelas
            </label>

            <select
                wire:model.live="classroomId"
                class="w-full rounded-lg
                       border border-zinc-300
                       px-3 py-2
                       dark:border-zinc-700
                       dark:bg-zinc-800"
            >
                <option value="">
                    Semua Kelas
                </option>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($classroom->id); ?>">
                        <?php echo e($classroom->name); ?>

                    </option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
        </div>

        <div>
            <label
                class="mb-1 block text-sm font-medium"
            >
                Sumber Laporan
            </label>

            <select
                wire:model.live="closureId"
                class="w-full rounded-lg
                    border border-zinc-300
                    bg-white px-3 py-2
                    text-sm
                    dark:border-zinc-700
                    dark:bg-zinc-950"
            >

                <option value="">
                    Data Berjalan
                </option>


                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $closures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $closure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                    <option
                        value="<?php echo e($closure->id); ?>"
                    >
                        Versi <?php echo e($closure->version); ?>

                        —
                        <?php echo e($closure
                            ->locked_at
                            ?->format(
                                'd/m/Y H:i'
                            )); ?>


                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($closure->isLocked()): ?>
                            — Terkunci
                        <?php else: ?>
                            — Dibuka Kembali
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </option>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

            </select>
        </div>

        <div>
            <label class="mb-1 block text-sm font-medium">
                Cari Siswa
            </label>

            <input
                wire:model.live.debounce.300ms="search"
                type="search"
                placeholder="Nama / NIS..."
                class="w-full rounded-lg
                       border border-zinc-300
                       px-3 py-2
                       dark:border-zinc-700
                       dark:bg-zinc-800"
            >
        </div>

    </div>


    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $selectedConfig): ?>

        <div
            class="rounded-xl border
                   border-amber-200
                   bg-amber-50 p-6
                   text-sm text-amber-700
                   dark:border-amber-900
                   dark:bg-amber-950
                   dark:text-amber-300"
        >
            Belum ada konfigurasi penilaian aktif
            untuk tahun ajaran dan semester ini.
        </div>

    <?php else: ?>

        <div>
            <div class="font-semibold">
                <?php echo e($selectedConfig->name); ?>

            </div>

            <div class="text-sm text-zinc-500">
                <?php echo e($selectedConfig->academicYear?->name); ?>

                ·
                <?php echo e($selectedConfig->semester?->name); ?>

            </div>
        </div>


        <div
            class="overflow-x-auto rounded-xl
                   border border-zinc-200
                   bg-white
                   dark:border-zinc-800
                   dark:bg-zinc-900"
        >

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                $syncStatus
                &&
                (
                    $syncStatus['attendance']['is_stale']
                    ||
                    $syncStatus['final']['is_stale']
                )
            ): ?>

                <div
                    class="rounded-xl border
                        border-amber-300
                        bg-amber-50
                        px-4 py-3
                        text-sm
                        text-amber-800
                        dark:border-amber-900
                        dark:bg-amber-950/40
                        dark:text-amber-300"
                >

                    <div class="font-semibold">
                        Data nilai belum sinkron

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assessment_sync.view')): ?>

                            <div class="mt-3">

                                <a
                                    href="<?php echo e(route(
                                        'assessment-sync.index'
                                    )); ?>"
                                    wire:navigate
                                    class="inline-flex
                                        rounded-lg
                                        bg-amber-700
                                        px-4 py-2
                                        text-xs font-medium
                                        text-white
                                        hover:bg-amber-800"
                                >
                                    Buka Sinkronisasi Penilaian
                                </a>

                            </div>

                        <?php endif; ?>
                    </div>

                    <p class="mt-1">
                        Sebagian nilai belum menggunakan
                        konfigurasi penilaian terbaru.
                        Lakukan sinkronisasi sebelum
                        mencetak atau mengekspor laporan.
                    </p>


                    <div
                        class="mt-3 flex flex-wrap gap-4
                            text-xs"
                    >

                        <span>
                            Nilai Kehadiran:
                            <strong>
                                <?php echo e(number_format(
                                    $syncStatus[
                                        'attendance'
                                    ][
                                        'stale_count'
                                    ]
                                )); ?>

                            </strong>
                            belum sinkron
                        </span>


                        <span>
                            Nilai Akhir:
                            <strong>
                                <?php echo e(number_format(
                                    $syncStatus[
                                        'final'
                                    ][
                                        'stale_count'
                                    ]
                                )); ?>

                            </strong>
                            belum sinkron
                        </span>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                            (
                                $syncStatus[
                                    'final'
                                ][
                                    'configuration_changed_count'
                                ]
                                ?? 0
                            ) > 0
                        ): ?>

                            <span>
                                Konfigurasi berubah:
                                <strong>
                                    <?php echo e(number_format(
                                        $syncStatus[
                                            'final'
                                        ][
                                            'configuration_changed_count'
                                        ]
                                    )); ?>

                                </strong>
                                siswa
                            </span>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    </div>

                </div>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['export'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                <div
                    class="rounded-lg border
                        border-red-200
                        bg-red-50
                        px-4 py-3
                        text-sm
                        text-red-700
                        dark:border-red-900
                        dark:bg-red-950/40
                        dark:text-red-300"
                >
                    <?php echo e($message); ?>

                </div>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                $reportSource
                === 'snapshot'
                &&
                $selectedClosure
            ): ?>

                <div
                    class="rounded-xl border
                        border-green-200
                        bg-green-50
                        px-4 py-4
                        text-sm
                        text-green-800
                        dark:border-green-900
                        dark:bg-green-950/40
                        dark:text-green-300"
                >

                    <div
                        class="flex flex-col gap-3
                            lg:flex-row
                            lg:items-center
                            lg:justify-between"
                    >

                        <div>

                            <div class="font-semibold">
                                Snapshot Nilai Resmi
                            </div>

                            <p class="mt-1">
                                Laporan menggunakan snapshot
                                semester versi
                                <strong>
                                    <?php echo e($selectedClosure->version); ?>

                                </strong>
                                yang dibuat pada
                                <?php echo e($selectedClosure
                                    ->locked_at
                                    ?->format(
                                        'd/m/Y H:i'
                                    )); ?>.
                            </p>

                        </div>


                        <div
                            class="rounded-lg
                                bg-white/70
                                px-3 py-2
                                font-mono
                                text-xs
                                dark:bg-zinc-900/60"
                            title="<?php echo e($selectedClosure->snapshot_checksum); ?>"
                        >
                            Checksum:
                            <?php echo e($selectedClosure
                                    ->snapshot_checksum
                                    ? substr(
                                        $selectedClosure
                                            ->snapshot_checksum,
                                        0,
                                        16
                                    )
                                        . '...'
                                    : '-'); ?>

                        </div>

                    </div>

                </div>

            <?php else: ?>

                <div
                    class="rounded-xl border
                        border-blue-200
                        bg-blue-50
                        px-4 py-3
                        text-sm
                        text-blue-700
                        dark:border-blue-900
                        dark:bg-blue-950/40
                        dark:text-blue-300"
                >
                    <strong>
                        Data Berjalan
                    </strong>

                    <span class="ml-1">
                        Laporan menggunakan nilai terkini
                        dari StudentScore dan FinalGrade.
                    </span>
                </div>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <table class="w-full text-left text-sm">

                <thead>
                    <tr
                        class="border-b
                               border-zinc-200
                               text-zinc-500
                               dark:border-zinc-800"
                    >
                        <th class="whitespace-nowrap p-3">
                            NIS
                        </th>

                        <th class="min-w-48 p-3">
                            Nama
                        </th>

                        <th class="p-3">
                            Kelas
                        </th>


                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $selectedConfig->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <th class="min-w-32 p-3">
                                <?php echo e($item->factor->name); ?>


                                <div class="text-xs font-normal">
                                    <?php echo e(number_format(
                                        $item->weight,
                                        2
                                    )); ?>%
                                </div>
                            </th>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>


                        <th class="p-3">
                            Akhir
                        </th>

                        <th class="p-3">
                            Predikat
                        </th>

                        <th class="min-w-40 p-3">
                            Deskripsi
                        </th>
                    </tr>
                </thead>


                <tbody>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                        <?php
                            $studentScores =
                                $scores->get(
                                    $student->id,
                                    collect()
                                );

                            $final =
                                $finalGrades->get(
                                    $student->id
                                );

                            $enrollment =
                                $student
                                    ->enrollments
                                    ->first();
                        ?>


                        <tr
                            <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'grade-report-'.e($student->id).''; ?>wire:key="grade-report-<?php echo e($student->id); ?>"
                            class="border-b
                                   border-zinc-100
                                   dark:border-zinc-800"
                        >

                            <td class="p-3">
                                <?php echo e($student->nis); ?>

                            </td>

                            <td class="p-3 font-medium">
                                <?php echo e($student->name); ?>

                            </td>

                            <td class="p-3">
                                <?php echo e($enrollment
                                    ?->classroom
                                    ?->name ?? '-'); ?>

                            </td>


                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $selectedConfig->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                                <?php
                                    $score =
                                        $studentScores->get(
                                            $item
                                                ->assessment_factor_id
                                        );
                                ?>

                                <td class="p-3">
                                    <?php echo e($score
                                        ? number_format(
                                            $score->score,
                                            2
                                        )
                                        : '-'); ?>

                                </td>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>


                            <td class="p-3 font-semibold">
                                <?php echo e($final
                                    ? number_format(
                                        $final->final_score,
                                        2
                                    )
                                    : '-'); ?>

                            </td>

                            <td class="p-3 font-semibold">
                                <?php echo e($final
                                    ?->letter_grade ?? '-'); ?>

                            </td>

                            <td class="p-3">
                                <?php echo e($final
                                    ?->description ?? '-'); ?>

                            </td>

                        </tr>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                        <tr>
                            <td
                                colspan="20"
                                class="p-8 text-center
                                       text-zinc-500"
                            >
                                Tidak ada data siswa.
                            </td>
                        </tr>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </tbody>
            </table>

        </div>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</div><?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/livewire/reports/grades.blade.php ENDPATH**/ ?>