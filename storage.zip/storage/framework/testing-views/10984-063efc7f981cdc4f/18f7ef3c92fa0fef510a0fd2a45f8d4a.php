<?php
    $signatoryService = app(\App\Services\DocumentSignatoryService::class);

    $principal = $signatoryService->configured($documentSetting, 'principal', (int) $school->id);
    $responsible = $signatoryService->configured($documentSetting, 'responsible', (int) $school->id);

    $legacyCoach = $documentSetting?->responsibleCoach;

    $principalName = $principal['name'] ?? $documentSetting?->principal_name;
    $principalPosition = $principal['position'] ?? 'Kepala Sekolah';
    $principalIdentity = $principal['identity']
        ?? ($documentSetting?->principal_nip ? 'NIP. '.$documentSetting->principal_nip : '');

    $responsibleName = $responsible['name'] ?? $legacyCoach?->name;
    $responsiblePosition = $responsible['position'] ?? 'Pembina Pramuka';
    $responsibleIdentity = $responsible['identity']
        ?? ($legacyCoach?->nip ? 'NTA. '.$legacyCoach->nip : '');

    $signingCity = $documentSetting?->signing_city ?: $school->city ?: '................';
?>

<table class="signature">
    <tr>
        <td>
            Mengetahui,<br>
            <?php echo e($principalPosition); ?>

            <div class="signature-space"></div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($principalName): ?>
                <strong><?php echo e($principalName); ?></strong>
            <?php else: ?>
                ______________________________
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <br>
            <?php echo e($principalIdentity ?: '________________________'); ?>

        </td>

        <td>
            <?php echo e($signingCity); ?>, <?php echo e(now()->locale('id')->translatedFormat('d F Y')); ?><br>
            <?php echo e($responsiblePosition); ?>

            <div class="signature-space"></div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($responsibleName): ?>
                <strong><?php echo e($responsibleName); ?></strong>
            <?php else: ?>
                ______________________________
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <br>
            <?php echo e($responsibleIdentity ?: '________________________'); ?>

        </td>
    </tr>
</table>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/reports/pdf/partials/signature.blade.php ENDPATH**/ ?>