<?php

use Livewire\Component;

return new class extends Component {
    protected function view($data = [])
    {
        return app('view')->file('D:\laragon\www\SIMOPRAM-1/storage/framework/testing-views/10984-063efc7f981cdc4f/livewire/views/e92bf765.blade.php', $data);
    }
}; 