<div class="space-y-6">

    

    <div
        class="flex flex-col gap-4
               lg:flex-row
               lg:items-start
               lg:justify-between"
    >

        <div>
            <div
                class="text-sm text-zinc-500"
            >
                Input Nilai Kegiatan
            </div>

            <h1
                class="mt-1 text-2xl
                       font-semibold"
            >
                <?php echo e($assessment->title); ?>

            </h1>

            <p
                class="mt-1 text-sm
                       text-zinc-500"
            >
                <?php echo e($assessment->activity?->title ?? '-'); ?>

                ·
                Faktor:
                <?php echo e($assessment->factor?->name ?? '-'); ?>

                ·
                <?php echo e($assessment->mode === 'individual'
                    ? 'Individu'
                    : 'Regu'); ?>

            </p>
        </div>


        <a
            href="<?php echo e(route(
                'activity-assessments.edit',
                $assessment->id
            )); ?>"
            wire:navigate
            class="rounded-lg border
                   border-zinc-300
                   px-4 py-2
                   text-sm font-medium
                   dark:border-zinc-700"
        >
            Kelola Form
        </a>

    </div>


    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>

        <div
            class="rounded-lg border
                   border-green-200
                   bg-green-50
                   px-4 py-3
                   text-sm text-green-700
                   dark:border-green-900
                   dark:bg-green-950
                   dark:text-green-300"
        >
            <?php echo e(session('status')); ?>

        </div>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-sm text-red-600"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div
        class="rounded-xl border
            border-blue-200
            bg-blue-50
            px-4 py-3
            text-sm
            text-blue-700
            dark:border-blue-900
            dark:bg-blue-950/40
            dark:text-blue-300"
    >
        <div class="font-medium">
            Rekap nilai otomatis
        </div>

        <p class="mt-1 leading-6">
            Setiap nilai yang disimpan pada form ini
            akan direkap ke faktor
            <strong>
                <?php echo e($assessment->factor?->name ?? '-'); ?>

            </strong>.

            Perubahan rekap akan membuat nilai akhir
            siswa perlu dihitung ulang.
        </p>
    </div>

    

    <div
        class="rounded-xl border
               border-zinc-200
               bg-white p-5
               dark:border-zinc-800
               dark:bg-zinc-900"
    >

        <div
            class="flex items-center
                   justify-between gap-4"
        >
            <div>
                <div
                    class="text-sm text-zinc-500"
                >
                    Progres Penilaian
                </div>

                <div
                    class="mt-1 text-xl
                           font-semibold"
                >
                    <?php echo e($assessedCount); ?>

                    /
                    <?php echo e($totalTargets); ?>

                </div>
            </div>


            <?php
                $progress =
                    $totalTargets > 0
                        ? min(
                            100,
                            (
                                $assessedCount
                                /
                                $totalTargets
                            )
                            * 100
                        )
                        : 0;
            ?>

            <div
                class="text-sm font-medium"
            >
                <?php echo e(number_format(
                    $progress,
                    0
                )); ?>%
            </div>
        </div>


        <div
            class="mt-3 h-2 overflow-hidden
                   rounded-full
                   bg-zinc-100
                   dark:bg-zinc-800"
        >
            <div
                class="h-full rounded-full
                       bg-zinc-900
                       dark:bg-white"
                style="width: <?php echo e($progress); ?>%"
            ></div>
        </div>

    </div>


    <div
        class="grid gap-6
               lg:grid-cols-[320px_minmax(0,1fr)]"
    >

        

        <aside
            class="rounded-xl border
                   border-zinc-200
                   bg-white
                   dark:border-zinc-800
                   dark:bg-zinc-900"
        >

            <div
                class="border-b
                       border-zinc-200
                       p-4
                       dark:border-zinc-800"
            >

                <input
                    type="search"
                    wire:model.live.debounce.300ms="search"
                    placeholder="<?php echo e($assessment->mode === 'individual'
                        ? 'Cari siswa...'
                        : 'Cari regu...'); ?>"
                    class="w-full rounded-lg
                           border border-zinc-300
                           bg-white px-3 py-2
                           text-sm
                           dark:border-zinc-700
                           dark:bg-zinc-950"
                >

            </div>


            <div
                class="max-h-[650px]
                       overflow-y-auto"
            >

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                    <?php
                        $label =
                            $assessment->mode
                            === 'individual'
                                ? (
                                    $target
                                        ->student
                                        ?->name
                                    ?? 'Siswa tidak tersedia'
                                )
                                : (
                                    $target
                                        ->scoutUnit
                                        ?->name
                                    ?? 'Regu tidak tersedia'
                                );
                    ?>

                    <button
                        type="button"
                        <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'target-'.e($target->id).''; ?>wire:key="target-<?php echo e($target->id); ?>"
                        wire:click="selectTarget(<?php echo e($target->id); ?>)"
                        class="flex w-full
                               items-start
                               justify-between
                               gap-3
                               border-b
                               border-zinc-100
                               px-4 py-3
                               text-left
                               transition
                               hover:bg-zinc-50
                               dark:border-zinc-800
                               dark:hover:bg-zinc-800
                               <?php echo e($selectedTargetId === $target->id
                                    ? 'bg-zinc-100 dark:bg-zinc-800'
                                    : ''); ?>"
                    >

                        <div class="min-w-0">

                            <div
                                class="truncate
                                       text-sm
                                       font-medium"
                            >
                                <?php echo e($label); ?>

                            </div>


                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                                $assessment->mode
                                === 'individual'
                            ): ?>

                                <div
                                    class="mt-1 text-xs
                                           text-zinc-500"
                                >
                                    NIS:
                                    <?php echo e($target->student?->nis ?? '-'); ?>

                                </div>

                            <?php else: ?>

                                <div
                                    class="mt-1 text-xs
                                           text-zinc-500"
                                >
                                    <?php echo e($target->members->count()); ?>

                                    anggota
                                </div>

                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        </div>


                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                            $target->assessed_at
                        ): ?>

                            <div
                                class="shrink-0
                                       rounded-full
                                       bg-green-100
                                       px-2 py-1
                                       text-xs font-medium
                                       text-green-700
                                       dark:bg-green-950
                                       dark:text-green-300"
                            >
                                <?php echo e(number_format(
                                    $target->normalized_score,
                                    2
                                )); ?>

                            </div>

                        <?php else: ?>

                            <div
                                class="shrink-0
                                       text-xs
                                       text-zinc-400"
                            >
                                Belum
                            </div>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    </button>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                    <div
                        class="p-6 text-center
                               text-sm
                               text-zinc-500"
                    >
                        Tidak ada target penilaian.
                    </div>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </div>

        </aside>


        

        <main>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedTarget): ?>

                <form
                    wire:submit="save"
                    class="space-y-6"
                >

                    <section
                        class="rounded-xl border
                               border-zinc-200
                               bg-white p-6
                               dark:border-zinc-800
                               dark:bg-zinc-900"
                    >

                        <div
                            class="flex flex-col
                                   gap-4
                                   sm:flex-row
                                   sm:items-start
                                   sm:justify-between"
                        >

                            <div>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                                    $assessment->mode
                                    === 'individual'
                                ): ?>

                                    <h2
                                        class="text-xl
                                               font-semibold"
                                    >
                                        <?php echo e($selectedTarget
                                            ->student
                                            ?->name
                                            ?? '-'); ?>

                                    </h2>

                                    <p
                                        class="mt-1 text-sm
                                               text-zinc-500"
                                    >
                                        NIS:
                                        <?php echo e($selectedTarget
                                            ->student
                                            ?->nis
                                            ?? '-'); ?>

                                    </p>

                                <?php else: ?>

                                    <h2
                                        class="text-xl
                                               font-semibold"
                                    >
                                        <?php echo e($selectedTarget
                                            ->scoutUnit
                                            ?->name
                                            ?? '-'); ?>

                                    </h2>

                                    <p
                                        class="mt-1 text-sm
                                               text-zinc-500"
                                    >
                                        Penilaian Regu
                                    </p>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            </div>


                            <div
                                class="rounded-xl
                                       bg-zinc-100
                                       px-4 py-3
                                       text-center
                                       dark:bg-zinc-800"
                            >
                                <div
                                    class="text-xs
                                           text-zinc-500"
                                >
                                    Nilai Akhir Form
                                </div>

                                <div
                                    class="mt-1
                                           text-2xl
                                           font-semibold"
                                >
                                    <?php echo e(number_format(
                                        $previewScore,
                                        2
                                    )); ?>

                                </div>
                            </div>

                        </div>


                        

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                            $assessment->mode
                            === 'team'
                        ): ?>

                            <div
                                class="mt-5 rounded-lg
                                       border
                                       border-zinc-200
                                       bg-zinc-50
                                       p-4
                                       dark:border-zinc-700
                                       dark:bg-zinc-950"
                            >

                                <div
                                    class="text-sm
                                           font-medium"
                                >
                                    Snapshot Anggota Regu
                                </div>

                                <p class="mt-3 text-sm text-zinc-500">
                                    Tambahkan anggota aktif dari master regu ke penerima nilai kegiatan ini.
                                    Penerima sebelumnya tetap disimpan. Pastikan anggota tambahan memang mengikuti kegiatan.
                                </p>
                                <button
                                    type="button"
                                    wire:click="syncMembers"
                                    wire:confirm="Tambahkan anggota aktif regu yang belum tercantum sebagai penerima nilai kegiatan ini? Pastikan mereka memang mengikuti kegiatan. Nilai yang sudah disimpan tetap dipertahankan."
                                    wire:loading.attr="disabled"
                                    wire:target="syncMembers"
                                    class="mt-3 rounded-lg border border-zinc-300 px-3 py-2 text-sm disabled:opacity-50 dark:border-zinc-700"
                                >
                                    <span wire:loading.remove wire:target="syncMembers">Perbarui Anggota Penerima Nilai</span>
                                    <span wire:loading wire:target="syncMembers">Memperbarui anggota...</span>
                                </button>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['members'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                                <div
                                    class="mt-3
                                           flex flex-wrap
                                           gap-2"
                                >

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $selectedTarget
                                            ->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                                        <span
                                            class="rounded-full
                                                   bg-white
                                                   px-3 py-1
                                                   text-xs
                                                   shadow-sm
                                                   dark:bg-zinc-900"
                                        >
                                            <?php echo e($member
                                                ->student
                                                ?->name
                                                ?? '-'); ?>

                                        </span>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                                        <span
                                            class="text-sm
                                                   text-zinc-500"
                                        >
                                            Regu belum memiliki
                                            snapshot anggota.
                                        </span>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                </div>

                            </div>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    </section>


                    

                    <section
                        class="rounded-xl border
                               border-zinc-200
                               bg-white p-6
                               dark:border-zinc-800
                               dark:bg-zinc-900"
                    >

                        <h2
                            class="text-lg font-semibold"
                        >
                            Nilai Kriteria
                        </h2>


                        <div
                            class="mt-5 space-y-5"
                        >

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $assessment->criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                                <div
                                    <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'criterion-score-'.e($criterion->id).''; ?>wire:key="criterion-score-<?php echo e($criterion->id); ?>"
                                    class="rounded-lg border
                                           border-zinc-200
                                           p-4
                                           dark:border-zinc-700"
                                >

                                    <div
                                        class="flex flex-col
                                               gap-4
                                               sm:flex-row
                                               sm:items-center
                                               sm:justify-between"
                                    >

                                        <div>

                                            <div
                                                class="font-medium"
                                            >
                                                <?php echo e($criterion->name); ?>

                                            </div>

                                            <div
                                                class="mt-1
                                                       text-xs
                                                       text-zinc-500"
                                            >
                                                Maksimum:
                                                <?php echo e(number_format(
                                                    $criterion->max_score,
                                                    2
                                                )); ?>

                                                · Bobot:
                                                <?php echo e(number_format(
                                                    $criterion->weight,
                                                    2
                                                )); ?>%
                                            </div>


                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                                                $criterion->description
                                            ): ?>

                                                <div
                                                    class="mt-2
                                                           text-sm
                                                           text-zinc-500"
                                                >
                                                    <?php echo e($criterion->description); ?>

                                                </div>

                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        </div>


                                        <div
                                            class="w-full
                                                   sm:w-40"
                                        >

                                            <input
                                                type="number"
                                                wire:model.live.debounce.300ms="scores.<?php echo e($criterion->id); ?>"
                                                min="0"
                                                max="<?php echo e($criterion->max_score); ?>"
                                                step="0.01"
                                                class="w-full rounded-lg
                                                       border
                                                       border-zinc-300
                                                       bg-white
                                                       px-3 py-2
                                                       text-right
                                                       dark:border-zinc-700
                                                       dark:bg-zinc-950"
                                            >

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = [
                                                'scores.'
                                                . $criterion->id
                                            ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div
                                                    class="mt-1
                                                           text-xs
                                                           text-red-600"
                                                >
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        </div>

                                    </div>

                                </div>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                        </div>

                    </section>


                    

                    <section
                        class="rounded-xl border
                               border-zinc-200
                               bg-white p-6
                               dark:border-zinc-800
                               dark:bg-zinc-900"
                    >

                        <label
                            class="block
                                   text-sm
                                   font-medium"
                        >
                            Catatan Penilaian
                        </label>

                        <textarea
                            wire:model="notes"
                            rows="4"
                            class="mt-2 w-full
                                   rounded-lg border
                                   border-zinc-300
                                   bg-white px-3 py-2
                                   dark:border-zinc-700
                                   dark:bg-zinc-950"
                        ></textarea>

                    </section>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                        'activity_assessments.score'
                    )): ?>

                        <div
                            class="flex justify-end"
                        >
                            <button
                                type="submit"
                                wire:loading.attr="disabled"
                                wire:target="save"
                                class="rounded-lg
                                       bg-zinc-900
                                       px-6 py-2.5
                                       text-sm font-medium
                                       text-white
                                       disabled:opacity-50
                                       dark:bg-white
                                       dark:text-zinc-900"
                            >
                                <span
                                    wire:loading.remove
                                    wire:target="save"
                                >
                                    Simpan Nilai
                                </span>

                                <span
                                    wire:loading
                                    wire:target="save"
                                >
                                    Menyimpan...
                                </span>
                            </button>
                        </div>

                    <?php endif; ?>

                </form>

            <?php else: ?>

                <div
                    class="rounded-xl border
                           border-zinc-200
                           bg-white p-10
                           text-center
                           text-zinc-500
                           dark:border-zinc-800
                           dark:bg-zinc-900"
                >
                    Pilih siswa atau regu
                    untuk mulai melakukan penilaian.
                </div>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </main>

    </div>

</div>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/livewire/assessments/activities/score.blade.php ENDPATH**/ ?>