<div>
    <p style="white-space: pre-wrap"><?php echo e($messageText); ?></p>
</div>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/mail/outbound-message.blade.php ENDPATH**/ ?>