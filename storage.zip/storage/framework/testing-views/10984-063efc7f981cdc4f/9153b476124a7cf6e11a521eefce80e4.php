<section class="page-break">
    <?php echo $__env->make('reports.pdf.lpj.partials.letterhead', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="approval-title">
        <h1>LEMBAR PENGESAHAN</h1>
    </div>

    <table class="approval-meta">
        <tr><td>Nama Ekstrakurikuler</td><td>: Pramuka</td></tr>
        <tr><td>Nama Pembina</td><td>: <?php echo e($coachName); ?></td></tr>
        <tr><td>NTA</td><td>: <?php echo e($responsibleCoach?->nip ?: '-'); ?></td></tr>
        <tr><td>Hari dan waktu Pelaksanaan</td><td>: <?php echo e($schedule['dayName']); ?>, <?php echo e($schedule['startTime'] ?: '-'); ?><?php echo e($schedule['endTime'] ? ' - '.$schedule['endTime'].' WITA' : ''); ?></td></tr>
        <tr><td>Tempat Pelaksanaan</td><td>: <?php echo e($schedule['location']); ?></td></tr>
        <tr><td>Tahun Ajaran</td><td>: <?php echo e($academicYear->name); ?></td></tr>
        <tr><td>Semester</td><td>: <?php echo e($semester->name); ?></td></tr>
        <tr><td>Tempat</td><td>: <?php echo e($signingCity); ?></td></tr>
        <tr><td>Tanggal</td><td>: <?php echo e($signingDate->locale('id')->translatedFormat('d F Y')); ?></td></tr>
    </table>

    <div class="signature-block approval-signature-block">
        <table class="approval-signatures">
            <tr>
                <td><?php echo e($responsiblePosition); ?></td>
                <td><?php echo e($coordinatorPosition); ?></td>
            </tr>
            <tr><td class="signature-space"></td><td></td></tr>
            <tr>
                <td><span class="signature-name"><?php echo e($coachName); ?></span><br><?php echo e($coachIdentifier); ?></td>
                <td>
                    <span class="signature-name"><?php echo e($coordinatorName); ?></span><br>
                    <?php echo e($coordinatorIdentifier); ?>

                </td>
            </tr>
        </table>

        <div class="approval-principal">
            Mengetahui/Menyetujui:<br>
            <?php echo e($principalPosition); ?>

            <div class="signature-space"></div>
            <span class="signature-name"><?php echo e($principalName); ?></span><br>
            <?php echo e($principalIdentifier); ?>

        </div>
    </div>
</section>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/reports/pdf/lpj/partials/approval.blade.php ENDPATH**/ ?>