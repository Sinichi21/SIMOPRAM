<section class="page-break">
    <?php echo $__env->make('reports.pdf.lpj.partials.letterhead', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="document-title">
        DATA KEGIATAN EKSTRA / PENGEMBANGAN DIRI<br>
        TAHUN PELAJARAN <?php echo e($academicYear->name); ?>

    </div>

    <table class="data-table">
        <tr><td>1.</td><td>Nama Penanggung Jawab</td><td>: <?php echo e($coachName); ?></td></tr>
        <tr><td>2.</td><td>Nomor HP</td><td>: <?php echo e($responsibleCoach?->phone ?: '-'); ?></td></tr>
        <tr><td>3.</td><td>Nama Ekstra/Pengemb. Diri</td><td>: Pramuka</td></tr>
        <tr><td>4.</td><td>Hari Pelaksanaan Ekstra</td><td>: <?php echo e($schedule['dayName']); ?></td></tr>
        <tr>
            <td>5.</td><td>Jam Pelaksanaan Ekstra</td>
            <td>: <?php echo e($schedule['startTime'] ?: '-'); ?><?php echo e($schedule['endTime'] ? ' - '.$schedule['endTime'].' WITA' : ''); ?></td>
        </tr>
        <tr><td>6.</td><td>Tempat Pelaksanaan Ekstra</td><td>: <?php echo e($schedule['location']); ?></td></tr>
    </table>

    <div class="signature-block">
        <table class="signature-table">
            <tr>
                <td>Mengetahui/Menyetujui:<br><?php echo e($principalPosition); ?></td>
                <td><?php echo e($signingCity); ?>, <?php echo e($signingDate->locale('id')->translatedFormat('d F Y')); ?><br><?php echo e($responsiblePosition); ?></td>
            </tr>
            <tr><td class="signature-space"></td><td></td></tr>
            <tr>
                <td><span class="signature-name"><?php echo e($principalName); ?></span><br><?php echo e($principalIdentifier); ?></td>
                <td><span class="signature-name"><?php echo e($coachName); ?></span><br><?php echo e($coachIdentifier); ?></td>
            </tr>
        </table>
    </div>
</section>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/reports/pdf/lpj/partials/activity-data.blade.php ENDPATH**/ ?>