<?php
    $pramukaLogoFile = public_path('images/reports/logo-pramuka.png');
    $wosmLogoFile = public_path('images/reports/logo-wosm.png');

    $pramukaLogo = file_exists($pramukaLogoFile)
        ? 'data:image/png;base64,'.base64_encode(file_get_contents($pramukaLogoFile))
        : null;

    $wosmLogo = file_exists($wosmLogoFile)
        ? 'data:image/png;base64,'.base64_encode(file_get_contents($wosmLogoFile))
        : null;

    $letterheadAddress = trim((string) ($scoutGroup?->secretariat_address ?: $school->address));
    $postalCode = trim((string) $school->postal_code);

    // Hindari kode pos ganda bila alamat sekretariat/sekolah sudah memuat kode pos.
    if ($postalCode !== '' && ! preg_match('/(?:^|\D)'.preg_quote($postalCode, '/').'(?:\D|$)/u', $letterheadAddress)) {
        $letterheadAddress = trim($letterheadAddress.' '.$postalCode);
    }
?>

<header class="letterhead">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pramukaLogo): ?>
        <img
            class="letterhead-logo-left"
            src="<?php echo e($pramukaLogo); ?>"
            alt="Logo Gerakan Pramuka"
        >
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($wosmLogo): ?>
        <img
            class="letterhead-logo-right"
            src="<?php echo e($wosmLogo); ?>"
            alt="Logo WOSM"
        >
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="letterhead-title">
        GERAKAN PRAMUKA<br>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($documentSetting?->gudep_male_number): ?>
            GUGUSDEPAN <?php echo e(strtoupper($school->city ?: '')); ?>

            <?php echo e($documentSetting->gudep_male_number); ?><br>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($documentSetting?->gudep_female_number): ?>
            GUGUSDEPAN <?php echo e(strtoupper($school->city ?: '')); ?>

            <?php echo e($documentSetting->gudep_female_number); ?><br>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        PANGKALAN <?php echo e(strtoupper($school->name)); ?>

    </div>

    <div class="letterhead-address">
        <?php echo e($letterheadAddress); ?>

    </div>
</header>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/reports/pdf/lpj/partials/letterhead.blade.php ENDPATH**/ ?>