<div
    class="space-y-6"
    x-data="{
        locating: false,
        gpsError: '',

        checkIn(sessionId) {
            this.gpsError = '';

            if (! navigator.geolocation) {
                this.gpsError =
                    'Perangkat tidak mendukung geolocation.';

                return;
            }

            this.locating = true;

            navigator.geolocation.getCurrentPosition(
                async (position) => {
                    try {
                        await $wire.checkIn(
                            sessionId,
                            position.coords.latitude,
                            position.coords.longitude,
                            position.coords.accuracy
                        );
                    } finally {
                        this.locating = false;
                    }
                },

                (error) => {
                    this.locating = false;

                    switch (error.code) {
                        case 1:
                            this.gpsError =
                                'Izin lokasi ditolak.';
                            break;

                        case 2:
                            this.gpsError =
                                'Lokasi tidak dapat diperoleh.';
                            break;

                        case 3:
                            this.gpsError =
                                'Permintaan lokasi terlalu lama.';
                            break;

                        default:
                            this.gpsError =
                                'Gagal memperoleh lokasi.';
                    }
                },

                {
                    enableHighAccuracy: true,
                    timeout: 15000,
                    maximumAge: 0,
                }
            );
        }
    }"
>

    <div>
        <h1 class="text-2xl font-semibold">
            Absensi Saya
        </h1>

        <p class="mt-1 text-sm text-zinc-500">
            <?php echo e($student?->name ?? 'Absensi mandiri untuk siswa di sekolah aktif.'); ?>

        </p>
    </div>


    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $student): ?>
        <div class="rounded-xl border border-amber-300 bg-amber-50 p-6 text-amber-900 dark:border-amber-700 dark:bg-amber-950 dark:text-amber-100">
            <h2 class="font-semibold">Akun belum terhubung ke siswa aktif</h2>
            <p class="mt-2 text-sm leading-6">
                Absensi Saya digunakan oleh siswa. Pastikan sekolah yang dipilih sudah benar,
                lalu minta pengelola menghubungkan akun Anda dengan data siswa yang berstatus aktif.
                Untuk mencatat kehadiran sebagai pengelola, gunakan menu Absensi.
            </p>
        </div>
    <?php else: ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($successMessage): ?>

        <div
            class="rounded-lg border
                   border-green-200
                   bg-green-50 p-4
                   text-sm text-green-700"
        >
            <?php echo e($successMessage); ?>

        </div>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

        <div
            class="rounded-lg border
                   border-red-200
                   bg-red-50 p-4
                   text-sm text-red-700"
        >
            <?php echo e($message); ?>

        </div>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    <div
        x-show="gpsError"
        x-cloak
        class="rounded-lg border
               border-red-200
               bg-red-50 p-4
               text-sm text-red-700"
    >
        <span x-text="gpsError"></span>
    </div>


    <div class="space-y-4">

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

            <?php
                $attendance =
                    $session
                        ->attendances
                        ->first();
            ?>

            <div
                class="rounded-xl border
                       border-zinc-200
                       bg-white p-6
                       shadow-sm
                       dark:border-zinc-800
                       dark:bg-zinc-900"
            >

                <div
                    class="flex flex-col gap-4
                           md:flex-row
                           md:items-center
                           md:justify-between"
                >

                    <div>

                        <h2 class="text-lg font-semibold">
                            <?php echo e($session->activity->title); ?>

                        </h2>

                        <div
                            class="mt-1 text-sm
                                   text-zinc-500"
                        >
                            <?php echo e($session->name); ?>

                        </div>

                        <div
                            class="mt-2 text-sm
                                   text-zinc-500"
                        >
                            Dibuka:
                            <?php echo e($session->open_at
                                ->format('H:i')); ?>


                            ·

                            Ditutup:
                            <?php echo e($session->close_at
                                ->format('H:i')); ?>

                        </div>

                        <div
                            class="mt-1 text-sm
                                   text-zinc-500"
                        >
                            Radius:
                            <?php echo e($session->radius_m); ?>

                            meter
                        </div>

                    </div>


                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($attendance): ?>

                        <div
                            class="rounded-lg
                                   bg-green-100
                                   px-4 py-2
                                   text-sm font-semibold
                                   text-green-700"
                        >
                            Sudah Absen:
                            <?php echo e(ucfirst(
                                $attendance->status
                            )); ?>

                        </div>

                    <?php else: ?>

                        <button
                            type="button"
                            x-on:click="
                                checkIn(
                                    <?php echo e($session->id); ?>

                                )
                            "
                            x-bind:disabled="locating"
                            class="rounded-lg
                                   bg-zinc-900
                                   px-4 py-2
                                   text-sm font-semibold
                                   text-white
                                   disabled:opacity-50
                                   dark:bg-white
                                   dark:text-zinc-900"
                        >
                            <span
                                x-show="! locating"
                            >
                                Ambil Lokasi & Absen
                            </span>

                            <span
                                x-show="locating"
                            >
                                Mencari lokasi...
                            </span>
                        </button>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>

            </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

            <div
                class="rounded-xl border
                       border-zinc-200
                       bg-white p-8
                       text-center
                       text-zinc-500
                       dark:border-zinc-800
                       dark:bg-zinc-900"
            >
                Tidak ada sesi absensi
                yang sedang dibuka.
            </div>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/livewire/attendances/self-checkin.blade.php ENDPATH**/ ?>