<div class="space-y-6">

    <div>
        <h1 class="text-2xl font-semibold">
            Penilaian Kegiatan
        </h1>

        <p class="mt-1 text-sm text-zinc-500">
            Buat form penilaian untuk kegiatan Pramuka
            dengan mode individu maupun regu.
        </p>
    </div>

    <details class="rounded-xl border p-4">
        <summary class="cursor-pointer font-semibold">Input Poin Keaktifan per Kegiatan</summary>
        <div class="mt-3 grid gap-2 md:grid-cols-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'participation-link-'.e($activity->id).''; ?>wire:key="participation-link-<?php echo e($activity->id); ?>" wire:navigate href="<?php echo e(route('activity-participation.show', $activity->id)); ?>" class="rounded-lg border p-3 text-amber-700"><?php echo e($activity->title); ?> — Poin Keaktifan</a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </details>


    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>

        <div
            class="rounded-lg border
                   border-green-200
                   bg-green-50
                   px-4 py-3
                   text-sm text-green-700
                   dark:border-green-900
                   dark:bg-green-950
                   dark:text-green-300"
        >
            <?php echo e(session('status')); ?>

        </div>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activity_assessments.create')): ?>

        <form
            wire:submit="create"
            class="rounded-xl border
                   border-zinc-200
                   bg-white p-6
                   shadow-sm
                   dark:border-zinc-800
                   dark:bg-zinc-900"
        >

            <h2 class="text-lg font-semibold">
                Buat Form Penilaian
            </h2>
            <p class="mt-2 text-sm text-zinc-500">Untuk memasukkan nilai kegiatan khusus ke semester, pilih kegiatan dan faktor tujuan tanpa mencentang mode juri di bawah. Pastikan faktor tersebut memiliki bobot pada Pengaturan Penilaian. Absensi kegiatan khusus tidak digabung ke faktor kehadiran latihan rutin.</p>

            <label class="mt-4 flex items-center gap-2">
                <input type="checkbox" wire:model.live="isSpecial">
                Kegiatan khusus / lomba — dinilai juri, tidak masuk nilai semester
            </label>


            <div
                class="mt-5 grid gap-4
                       md:grid-cols-2"
            >

                <div>
                    <label class="mb-1 block text-sm font-medium">
                        Kegiatan
                    </label>

                    <select
                        wire:model="activityId"
                        class="w-full rounded-lg
                               border border-zinc-300
                               bg-white px-3 py-2
                               dark:border-zinc-700
                               dark:bg-zinc-950"
                    >
                        <option value="">
                            -- Pilih Kegiatan --
                        </option>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                            <option value="<?php echo e($activity->id); ?>">
                                <?php echo e($activity->title); ?>


                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activity->start_at): ?>
                                    -
                                    <?php echo e($activity->start_at
                                        ->format('d-m-Y')); ?>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </option>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['activityId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>


                <div>
                    <label class="mb-1 block text-sm font-medium">
                        Faktor Tujuan (hanya untuk nilai semester)
                    </label>

                    <select
                        wire:model="assessmentFactorId"
                        <?php if($isSpecial): echo 'disabled'; endif; ?>
                        class="w-full rounded-lg
                               border border-zinc-300
                               bg-white px-3 py-2
                               dark:border-zinc-700
                               dark:bg-zinc-950"
                    >
                        <option value="">
                            -- Pilih Faktor --
                        </option>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $factors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                            <option value="<?php echo e($factor->id); ?>">
                                <?php echo e($factor->name); ?>

                            </option>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['assessmentFactorId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>


                <div>
                    <label class="mb-1 block text-sm font-medium">
                        Nama Form
                    </label>

                    <input
                        type="text"
                        wire:model="title"
                        placeholder="Contoh: Praktik Tali-Temali"
                        class="w-full rounded-lg
                               border border-zinc-300
                               bg-white px-3 py-2
                               dark:border-zinc-700
                               dark:bg-zinc-950"
                    >

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>


                <div>
                    <label class="mb-1 block text-sm font-medium">
                        Mode Penilaian
                    </label>

                    <select
                        wire:model="mode"
                        class="w-full rounded-lg
                               border border-zinc-300
                               bg-white px-3 py-2
                               dark:border-zinc-700
                               dark:bg-zinc-950"
                    >
                        <option value="individual">
                            Individu
                        </option>

                        <option value="team">
                            Regu
                        </option>
                    </select>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

            </div>


            <div class="mt-4">

                <label class="mb-1 block text-sm font-medium">
                    Deskripsi
                </label>

                <textarea
                    wire:model="description"
                    rows="3"
                    class="w-full rounded-lg
                           border border-zinc-300
                           bg-white px-3 py-2
                           dark:border-zinc-700
                           dark:bg-zinc-950"
                ></textarea>

            </div>


            <div class="mt-5 flex justify-end">

                <button
                    type="submit"
                    wire:loading.attr="disabled"
                    wire:target="create"
                    class="rounded-lg
                           bg-zinc-900
                           px-5 py-2.5
                           text-sm font-medium
                           text-white
                           dark:bg-white
                           dark:text-zinc-900"
                >
                    <span
                        wire:loading.remove
                        wire:target="create"
                    >
                        Buat Form
                    </span>

                    <span
                        wire:loading
                        wire:target="create"
                    >
                        Membuat...
                    </span>
                </button>

            </div>

        </form>

    <?php endif; ?>


    <section
        class="rounded-xl border
               border-zinc-200
               bg-white
               shadow-sm
               dark:border-zinc-800
               dark:bg-zinc-900"
    >

        <div
            class="flex flex-col gap-3
                   border-b border-zinc-200
                   p-5
                   sm:flex-row
                   sm:items-center
                   sm:justify-between
                   dark:border-zinc-800"
        >

            <h2 class="font-semibold">
                Daftar Form Penilaian
            </h2>


            <div class="flex flex-col gap-2 sm:flex-row">
                <select
                    wire:model.live="scoutLevelId"
                    class="rounded-lg border border-zinc-300 bg-white px-3 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-950"
                >
                    <option value="">Semua Golongan</option>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $scoutLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scoutLevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <option value="<?php echo e($scoutLevel->id); ?>">
                            <?php echo e($scoutLevel->name); ?>

                        </option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>

                <input
                    type="search"
                    wire:model.live.debounce.300ms="search"
                    placeholder="Cari form..."
                    class="rounded-lg border border-zinc-300 bg-white px-3 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-950"
                >
            </div>

        </div>


        <div class="overflow-x-auto">

            <table class="w-full text-sm">

                <thead
                    class="bg-zinc-50
                           dark:bg-zinc-950"
                >
                    <tr>
                        <th class="px-4 py-3 text-left">
                            Form
                        </th>

                        <th class="px-4 py-3 text-left">
                            Kegiatan
                        </th>

                        <th class="px-4 py-3 text-left">
                            Faktor
                        </th>

                        <th class="px-4 py-3 text-center">
                            Mode
                        </th>

                        <th class="px-4 py-3 text-center">
                            Status
                        </th>

                        <th class="px-4 py-3 text-right">
                            Aksi
                        </th>
                    </tr>
                </thead>


                <tbody
                    class="divide-y
                           divide-zinc-200
                           dark:divide-zinc-800"
                >

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                        <tr>
                            <td class="px-4 py-3 font-medium">
                                <?php echo e($assessment->title); ?>

                            </td>

                            <td class="px-4 py-3">
                                <?php echo e($assessment->activity?->title ?? '-'); ?>


                                <div class="text-xs text-zinc-500">
                                    <?php echo e($assessment->activity?->scoutLevels->pluck('name')->join(', ') ?: 'Semua Golongan'); ?>

                                </div>
                            </td>

                            <td class="px-4 py-3">
                                <?php echo e($assessment->is_special ? 'Kegiatan khusus — tidak masuk semester' : ($assessment->factor?->name ?? '-')); ?>

                            </td>

                            <td class="px-4 py-3 text-center">
                                <?php echo e($assessment->mode === 'individual'
                                    ? 'Individu'
                                    : 'Regu'); ?>

                            </td>

                            <td class="px-4 py-3 text-center">

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($assessment->status === 'published'): ?>

                                    <span
                                        class="rounded-full
                                               bg-green-100
                                               px-2 py-1
                                               text-xs font-medium
                                               text-green-700
                                               dark:bg-green-950
                                               dark:text-green-300"
                                    >
                                        Published
                                    </span>

                                <?php else: ?>

                                    <span
                                        class="rounded-full
                                               bg-zinc-100
                                               px-2 py-1
                                               text-xs font-medium
                                               text-zinc-700
                                               dark:bg-zinc-800
                                               dark:text-zinc-300"
                                    >
                                        Draft
                                    </span>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            </td>

                            <td class="px-4 py-3 text-right">
                                <div
                                    class="flex justify-end gap-3"
                                >

                                    <a
                                        href="<?php echo e(route(
                                            'activity-assessments.edit',
                                            $assessment->id
                                        )); ?>"
                                        wire:navigate
                                        class="text-sm
                                            font-medium
                                            hover:underline"
                                    >
                                        Kelola
                                    </a>


                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(
                                        $assessment->status
                                        === 'published'
                                    ): ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(
                                            'activity_assessments.score'
                                        )): ?>

                                            <a
                                                href="<?php echo e(route(
                                                    $assessment->is_special ? 'activity-assessments.edit' : 'activity-assessments.score',
                                                    $assessment->id
                                                )); ?>"
                                                wire:navigate
                                                class="text-sm
                                                    font-medium
                                                    text-green-700
                                                    hover:underline
                                                    dark:text-green-400"
                                            >
                                                Input Nilai
                                            </a>

                                        <?php endif; ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                </div>

                            </td>
                        </tr>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                        <tr>
                            <td
                                colspan="6"
                                class="px-4 py-8
                                       text-center
                                       text-zinc-500"
                            >
                                Belum ada form penilaian kegiatan.
                            </td>
                        </tr>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</div>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/livewire/assessments/activities/index.blade.php ENDPATH**/ ?>