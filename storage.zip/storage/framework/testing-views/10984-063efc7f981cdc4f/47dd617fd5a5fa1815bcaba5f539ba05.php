<section class="cover page-break">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(is_file($coverBorderPath)): ?>
        <img class="cover-border" src="<?php echo e($coverBorderPath); ?>" alt="Border Pramuka">
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="cover-logos">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($schoolLogoPath): ?>
            <img src="<?php echo e($schoolLogoPath); ?>" alt="Logo Sekolah">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($scoutGroupLogoPath): ?>
            <img src="<?php echo e($scoutGroupLogoPath); ?>" alt="Logo Pramuka">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="cover-title">
        LAPORAN PERTANGGUNG JAWABAN<br>
        PELAKSANAAN KEGIATAN EKSTRA / PENGEMBANGAN DIRI<br>
        EKSTRA KURIKULER PRAMUKA
    </div>

    <div class="cover-author">
        OLEH:<br>
        <?php echo e(strtoupper($coachName)); ?>

    </div>

    <div class="cover-school">
        <?php echo e(strtoupper($school->name)); ?><br>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($documentSetting?->parent_agency): ?>
            <?php echo e(strtoupper($documentSetting->parent_agency)); ?><br>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo e(strtoupper($school->city ?: '')); ?><br>
        <?php echo e($periodEnd->format('Y')); ?>

    </div>
</section>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/reports/pdf/lpj/partials/cover.blade.php ENDPATH**/ ?>