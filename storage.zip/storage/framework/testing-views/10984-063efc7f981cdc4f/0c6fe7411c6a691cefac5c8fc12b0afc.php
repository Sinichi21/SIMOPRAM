<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['school' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['school' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<header class="relative z-40 border-b border-zinc-200 bg-white text-zinc-900 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100">
    <div class="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-4 lg:px-8">
        <a href="<?php echo e($school ? route('schools.landing', $school) : route('home')); ?>" class="flex min-w-0 items-center gap-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school?->logo): ?>
                <img src="<?php echo e(Storage::disk('public')->url($school->logo)); ?>" alt="Logo <?php echo e($school->name); ?>" class="size-11 shrink-0 rounded-xl bg-white object-contain p-1">
            <?php else: ?>
                <span class="grid size-11 shrink-0 place-items-center rounded-xl bg-emerald-800 font-black text-amber-300">S</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <span><strong class="block text-sm tracking-tight"><?php echo e($school?->name ?? 'SIMPRAM'); ?></strong><span class="text-[10px] font-bold tracking-widest text-emerald-700 dark:text-emerald-300">PRAMUKA DIGITAL</span></span>
        </a>
        <?php if (isset($component)) { $__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d = $attributes; } ?>
<?php $component = App\View\Components\AreaNavigation::resolve(['school' => $school] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('area-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AreaNavigation::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d)): ?>
<?php $attributes = $__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d; ?>
<?php unset($__attributesOriginalb944bbd83827acd4d63b33efc5c5ab3d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d)): ?>
<?php $component = $__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d; ?>
<?php unset($__componentOriginalb944bbd83827acd4d63b33efc5c5ab3d); ?>
<?php endif; ?>
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school || request()->routeIs('home')): ?>
        <nav aria-label="Navigasi halaman" class="mx-auto flex max-w-7xl flex-wrap gap-x-6 gap-y-2 px-5 pb-4 text-sm font-semibold text-zinc-600 lg:px-8 dark:text-zinc-300">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($school): ?>
                <a href="<?php echo e(route('schools.landing', $school)); ?>#profil">Profil sekolah</a>
                <a href="<?php echo e(route('schools.landing', $school)); ?>#agenda">Pengumuman & kegiatan</a>
                <a href="<?php echo e(route('schools.landing', $school)); ?>#dokumentasi">Dokumentasi</a>
                <a href="<?php echo e(route('schools.landing', $school)); ?>#kontak">Kontak</a>
            <?php else: ?>
                <a href="#fitur">Fitur</a><a href="#sekolah">Sekolah</a><a href="#daftar-sekolah">Daftarkan sekolah</a><a href="<?php echo e(route('complaints.public')); ?>">Pengaduan</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </nav>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</header>
<?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/components/public-header.blade.php ENDPATH**/ ?>