<div class="space-y-6">

    <div
        class="flex flex-col gap-4
               lg:flex-row
               lg:items-end
               lg:justify-between"
    >

        <div>
            <h1 class="text-2xl font-semibold">
                Rekap Absensi
            </h1>

            <p class="mt-1 text-sm text-zinc-500">
                Rekap kehadiran siswa berdasarkan
                tahun ajaran, semester, dan kelas.
            </p>
        </div>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.export')): ?>

            <div class="flex flex-wrap gap-2">

                <button
                    type="button"
                    wire:click="exportCsv"
                    wire:loading.attr="disabled"
                    wire:target="exportCsv"
                    class="rounded-lg border
                        border-zinc-300
                        px-4 py-2
                        text-sm font-medium
                        hover:bg-zinc-50
                        disabled:opacity-50
                        dark:border-zinc-700
                        dark:hover:bg-zinc-800"
                >
                    <span
                        wire:loading.remove
                        wire:target="exportCsv"
                    >
                        Export CSV
                    </span>

                    <span
                        wire:loading
                        wire:target="exportCsv"
                    >
                        Memproses...
                    </span>
                </button>


                <button
                    type="button"
                    wire:click="exportExcel"
                    wire:loading.attr="disabled"
                    wire:target="exportExcel"
                    class="rounded-lg border
                        border-zinc-300
                        px-4 py-2
                        text-sm font-medium
                        hover:bg-zinc-50
                        disabled:opacity-50
                        dark:border-zinc-700
                        dark:hover:bg-zinc-800"
                >
                    <span
                        wire:loading.remove
                        wire:target="exportExcel"
                    >
                        Export Excel
                    </span>

                    <span
                        wire:loading
                        wire:target="exportExcel"
                    >
                        Memproses...
                    </span>
                </button>

                <a
                    href="<?php echo e(route(
                        'reports.attendance.pdf',
                        array_filter([
                            'academic_year_id' =>
                                $academicYearId,

                            'semester_id' =>
                                $semesterId,

                            'classroom_id' =>
                                $classroomId,
                        ])
                    )); ?>"
                    target="_blank"
                    class="inline-flex items-center
                        rounded-lg
                        bg-zinc-900
                        px-4 py-2
                        text-sm font-medium
                        text-white
                        hover:bg-zinc-800
                        dark:bg-white
                        dark:text-zinc-900"
                >
                    Export PDF
                </a>

            </div>

        <?php endif; ?>

    </div>


    <div
        class="grid gap-4 rounded-xl
               border border-zinc-200
               bg-white p-5
               md:grid-cols-4
               dark:border-zinc-800
               dark:bg-zinc-900"
    >

        <div>

            <label class="mb-1 block text-sm font-medium">
                Tahun Ajaran
            </label>

            <select
                wire:model.live="academicYearId"
                class="w-full rounded-lg border
                       border-zinc-300 px-3 py-2
                       dark:border-zinc-700
                       dark:bg-zinc-800"
            >
                <option value="">
                    -- Pilih --
                </option>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($year->id); ?>">
                        <?php echo e($year->name); ?>

                    </option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>

        </div>


        <div>

            <label class="mb-1 block text-sm font-medium">
                Semester
            </label>

            <select
                wire:model.live="semesterId"
                class="w-full rounded-lg border
                       border-zinc-300 px-3 py-2
                       dark:border-zinc-700
                       dark:bg-zinc-800"
            >
                <option value="">
                    Semua Semester
                </option>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($semester->id); ?>">
                        <?php echo e($semester->name); ?>

                    </option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>

        </div>


        <div>

            <label class="mb-1 block text-sm font-medium">
                Kelas
            </label>

            <select
                wire:model.live="classroomId"
                class="w-full rounded-lg border
                       border-zinc-300 px-3 py-2
                       dark:border-zinc-700
                       dark:bg-zinc-800"
            >
                <option value="">
                    Semua Kelas
                </option>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($classroom->id); ?>">
                        <?php echo e($classroom->name); ?>

                    </option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>

        </div>


        <div>

            <label class="mb-1 block text-sm font-medium">
                Cari Siswa
            </label>

            <input
                wire:model.live.debounce.300ms="search"
                type="search"
                placeholder="Nama / NIS..."
                class="w-full rounded-lg border
                       border-zinc-300 px-3 py-2
                       dark:border-zinc-700
                       dark:bg-zinc-800"
            >

        </div>

    </div>


    <div
        class="grid gap-4
               sm:grid-cols-2
               lg:grid-cols-3"
    >

        <div
            class="rounded-xl border
                   border-zinc-200
                   bg-white p-5
                   dark:border-zinc-800
                   dark:bg-zinc-900"
        >
            <div class="text-sm text-zinc-500">
                Sesi Absensi
            </div>

            <div class="mt-2 text-3xl font-semibold">
                <?php echo e($sessionCount); ?>

            </div>
        </div>


        <div
            class="rounded-xl border
                   border-zinc-200
                   bg-white p-5
                   dark:border-zinc-800
                   dark:bg-zinc-900"
        >
            <div class="text-sm text-zinc-500">
                Siswa
            </div>

            <div class="mt-2 text-3xl font-semibold">
                <?php echo e($rows->count()); ?>

            </div>
        </div>

    </div>


    <div
        class="overflow-x-auto
               rounded-xl border
               border-zinc-200
               bg-white
               dark:border-zinc-800
               dark:bg-zinc-900"
    >

        <table class="w-full text-left text-sm">

            <thead>

                <tr
                    class="border-b
                           border-zinc-200
                           text-zinc-500
                           dark:border-zinc-800"
                >

                    <th class="p-3">
                        NIS
                    </th>

                    <th class="min-w-48 p-3">
                        Nama
                    </th>

                    <th class="p-3">
                        Kelas
                    </th>

                    <th class="p-3">
                        Pertemuan
                    </th>

                    <th class="p-3">
                        Hadir
                    </th>

                    <th class="p-3">
                        Terlambat
                    </th>

                    <th class="p-3">
                        Sakit
                    </th>

                    <th class="p-3">
                        Izin
                    </th>

                    <th class="p-3">
                        Alpa
                    </th>

                    <th class="p-3">
                        Belum Dicatat
                    </th>

                    <th class="p-3">
                        % Hadir
                    </th>

                </tr>

            </thead>


            <tbody>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                    <?php
                        $student =
                            $row['student'];

                        $enrollment =
                            $student
                                ->enrollments
                                ->first();
                    ?>


                    <tr
                        <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'attendance-report-'.e($student->id).''; ?>wire:key="attendance-report-<?php echo e($student->id); ?>"
                        class="border-b
                               border-zinc-100
                               dark:border-zinc-800"
                    >

                        <td class="p-3">
                            <?php echo e($student->nis); ?>

                        </td>

                        <td class="p-3 font-medium">
                            <?php echo e($student->name); ?>

                        </td>

                        <td class="p-3">
                            <?php echo e($enrollment
                                ?->classroom
                                ?->name ?? '-'); ?>

                        </td>

                        <td class="p-3">
                            <?php echo e($row['participants']); ?>

                        </td>

                        <td class="p-3">
                            <?php echo e($row['present']); ?>

                        </td>

                        <td class="p-3">
                            <?php echo e($row['late']); ?>

                        </td>

                        <td class="p-3">
                            <?php echo e($row['sick']); ?>

                        </td>

                        <td class="p-3">
                            <?php echo e($row['excused']); ?>

                        </td>

                        <td class="p-3">
                            <?php echo e($row['absent']); ?>

                        </td>

                        <td class="p-3">
                            <?php echo e($row['unrecorded']); ?>

                        </td>

                        <td class="p-3 font-semibold">

                            <?php echo e(number_format(
                                $row[
                                    'presence_percentage'
                                ],
                                2
                            )); ?>%

                        </td>

                    </tr>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                    <tr>
                        <td
                            colspan="11"
                            class="p-8 text-center
                                   text-zinc-500"
                        >
                            Tidak ada data absensi.
                        </td>
                    </tr>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </tbody>

        </table>

    </div>

</div><?php /**PATH D:\laragon\www\SIMOPRAM-1\resources\views/livewire/reports/attendance.blade.php ENDPATH**/ ?>